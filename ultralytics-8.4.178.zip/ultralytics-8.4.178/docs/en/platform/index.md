---
plans: [free, pro, enterprise]
comments: true
description: Ultralytics Platform is an end-to-end computer vision platform for data preparation, model training, and deployment with multi-region infrastructure.
keywords: Ultralytics Platform, YOLO, computer vision, model training, cloud deployment, annotation, inference, YOLO11, YOLO26, machine learning
---

# Ultralytics Platform

[Ultralytics Platform](https://platform.ultralytics.com) is a comprehensive end-to-end computer vision platform that streamlines the entire ML workflow from data preparation to model deployment. Built for teams and individuals who need production-ready [computer vision](https://www.ultralytics.com/glossary/computer-vision-cv) solutions without the infrastructure complexity.

![Ultralytics Platform Dataset Screenshot](https://cdn.ul.run/i/2141b069efb0284ebee4bc23847f999c.avif)<!-- screenshot -->

## What is Ultralytics Platform?

Ultralytics Platform brings dataset management and annotation, experiment tracking, cloud and remote training, model export, dedicated inference endpoints, and deployment monitoring into one workspace. It has native support for [YOLO26](../models/yolo26.md), [YOLO11](../models/yolo11.md), [YOLOv8](../models/yolov8.md), and [YOLOv5](../models/yolov5.md) models.

## Workflow: Upload → Annotate → Train → Export or Deploy

The Platform provides an end-to-end workflow:

```mermaid
flowchart TD
    subgraph data["Data"]
        direction TB
        A([Upload]) --> B[Annotate]
    end
    subgraph train["Train"]
        direction TB
        C[Configure] --> D[Train on GPU]
    end
    data --> train
    train --> E{Export or deploy?}
    E -->|export| F([Export])
    E -->|deploy| G[Deploy endpoint]
    G --> H([Monitor])
```

| Stage        | Features                                                                                                                                                                                                                                                                                                                                                                                   |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Upload**   | Images (50MB), videos (1GB), and dataset files (ZIP, TAR including `.tar.gz`/`.tgz`, NDJSON) from your machine, a URL, cloud storage, or an on-premise host                                                                                                                                                                                                                                |
| **Annotate** | Manual annotation tools for 6 task types, plus [Smart Annotation](data/annotation.md#smart-annotation) with SAM models for detect, segment, semantic, and OBB, YOLO models for those tasks and pose, or class-prompted models (hosted open-source or paid provider models) for detection datasets with 1–200 classes (see [supported task types](data/annotation.md#supported-task-types)) |
| **Train**    | Cloud GPUs (24 on all plans + 2 Pro/Enterprise-only: B200, B300), real-time metrics, project organization                                                                                                                                                                                                                                                                                  |
| **Export**   | [22 deployment formats](../modes/export.md) (ONNX, TensorRT, CoreML, LiteRT, Hailo, Ascend, etc.; see [supported formats](train/models.md#supported-formats))                                                                                                                                                                                                                              |
| **Deploy**   | 42 global regions with dedicated endpoints, scale-to-zero by default (single active instance), and monitoring                                                                                                                                                                                                                                                                              |

**What you can do:**

- **Upload** images, videos, and dataset files to create training datasets
- **Visualize** annotations with interactive overlays for the 6 YOLO task types supported by the annotation editor (see [supported task types](data/annotation.md#supported-task-types))
- **Train** models on cloud GPUs (24 on all plans, 26 with Pro or Enterprise for B200 and B300) with real-time metrics
- **Export** to [22 deployment formats](../modes/export.md) (ONNX, TensorRT, CoreML, LiteRT, Hailo, Ascend, etc.)
- **Deploy** to 42 global regions with one-click dedicated endpoints
- **Build [Agents workflows](agents.md)** that connect models, conditions, dataset collection, Slack alerts, and webhooks
- **Monitor** training progress, deployment health, and usage metrics
- **Connect** cloud storage, annotation tools, and Slack through [integrations](integrations/index.md)
- **Collaborate** by making projects and datasets public for the community

## Multi-Region Infrastructure

Your data stays in your region. Ultralytics Platform operates infrastructure in three global regions:

{% include "macros/platform-data-regions.md" %}

You select your data region during onboarding. Datasets, models, and managed training data remain in that region.
Dedicated endpoints are deployed separately to a region you choose from the global deployment map.

!!! warning "Region is Permanent"

    You cannot change your data region yourself after account creation. During onboarding, the Platform measures latency to each region and recommends the closest one. Contact support if you later need to request a region change. This applies to dataset and model content; account-level data such as profile, billing, and activity records is processed globally, as described in our [Privacy Policy](https://www.ultralytics.com/legal/privacy) and [Data Processing Agreement](https://www.ultralytics.com/legal/ultralytics-data-processing-agreement#exhibit-a-details-of-personal-data-processing).

## Key Features

### Data Preparation

- **Dataset Management**: Create datasets from local files, a URL, connected [cloud storage](integrations/index.md), or an [on-premise host](integrations/on-premise.md), with automatic processing
- **[Annotation Editor](https://www.ultralytics.com/annotate)**: Manual annotation tools for 6 YOLO task types (detect, segment, semantic, classify, pose, OBB; see [supported task types](data/annotation.md#supported-task-types))
- **Skeleton Templates**: Built-in (Person, Hand, Dog, Face, Box) and custom skeleton templates for one-click pose annotation
- **Smart Annotation**: Use [SAM 2.1](../models/sam-2.md) (Tiny, Small, Base, Large), [SAM 3](../models/sam-3.md), or [SAM 3.1](../models/sam-3.md#sam-31) (default) from the annotation toolbar for detect, segment, semantic, and OBB tasks, pretrained Ultralytics YOLO models and your own fine-tuned YOLO models for those tasks and pose, or class-prompted models on detection datasets with 1–200 classes: six hosted open-source models (Moondream 3.1 by default), hosted text-prompted SAM 3 and SAM 3.1, or paid vision models from OpenAI, Anthropic, Google, Meta, SpaceXAI, DeepSeek, Z.ai, Kimi, and Xiaomi MiMo with a provider key from **Settings > API Keys**
- **Dataset Versioning**: Create numbered NDJSON snapshots with descriptions, then download or restore any version for reproducible training
- **Statistics**: Class distribution, split distribution, location heatmaps, and bounding box dimension analysis

```mermaid
flowchart TD
    A([Upload data]) --> B[Automatic processing]
    B --> C[Browse and filter]
    C --> D{Annotation mode?}
    D -->|draw| E[Manual tools]
    D -->|smart| F[SAM or model labels]
    E --> G([Train-ready dataset])
    F --> G
```

!!! tip "Supported Task Types"

    The annotation editor provides tools for 6 YOLO task types: **[detect](../datasets/detect/index.md)** (bounding boxes), **[segment](../datasets/segment/index.md)** (polygons), **[semantic](../datasets/semantic/index.md)** (per-class regions), **[classify](../datasets/classify/index.md)** (image-level labels), **[pose](../datasets/pose/index.md)** (keypoints), and **[OBB](../datasets/obb/index.md)** (oriented boxes). Each task type has dedicated annotation controls and keyboard shortcuts.

### Model Training

- **Cloud Training**: Train on cloud GPUs (24 on all plans, 26 with [Pro or Enterprise](account/billing.md#plans) for B200 and B300) with real-time metrics and a live cost estimate
- **Remote Training**: Train anywhere and stream metrics to Ultralytics Platform
- **Advanced Settings**: Override any Ultralytics training argument from a built-in YAML editor in the training dialog
- **Project Organization**: Group related models, compare experiments, track activity
- **22 Export Formats**: ONNX, TensorRT, CoreML, LiteRT, Hailo, Ascend, and more (see [supported formats](train/models.md#supported-formats))

![Ultralytics Platform Project Screenshot](https://cdn.ul.run/i/78d6e38a07e3885956acdce96a7fc061.avif)<!-- screenshot -->

You can train models either through the web UI (cloud training) or from your own machine (remote training):

=== "Cloud Training (Web UI)"

    1. Navigate to your project
    2. Click `New Model`
    3. Select dataset, model, GPU, and epochs
    4. Monitor real-time loss curves and metrics

=== "Remote Training (CLI)"

    ```bash
    # Install ultralytics
    pip install "ultralytics>=8.4.120"

    # Set your API key
    export ULTRALYTICS_API_KEY="YOUR_API_KEY"

    # Train and stream metrics to the platform
    yolo train model=yolo26n.pt data=coco.yaml epochs=100 project=username/my-project name=exp1
    ```

=== "Remote Training (Python)"

    ```python
    import os

    from ultralytics import YOLO

    os.environ["ULTRALYTICS_API_KEY"] = "YOUR_API_KEY"

    model = YOLO("yolo26n.pt")
    model.train(
        data="coco.yaml",
        epochs=100,
        project="username/my-project",
        name="exp1",
    )
    # Metrics stream to Platform automatically
    ```

### Deployment

- **Inference Testing**: Test models directly in the browser with your own images, a webcam capture, or the built-in examples
- **Dedicated Endpoints**: Deploy to 42 global regions with scale-to-zero by default (single active instance)
- **Monitoring**: Real-time metrics, request logs, and performance dashboards

```mermaid
flowchart TD
    A([Trained model]) --> B{Test it first?}
    B -->|yes| C[Test in the browser]
    B -->|no| D{Export or deploy?}
    C --> D
    D -->|export| E[22 formats]
    D -->|deploy| F[42 regions]
    F --> G[Endpoint URL]
    G --> H([Monitor and scale])
```

Once deployed, call your endpoint from any language. `conf`, `iou`, and `imgsz` are optional form fields that default to
`0.25`, `0.7`, and the model's training image size (640 if unavailable):

=== "Python"

    ```python
    import requests

    url = "https://your-deployment-url.run.app/predict"
    api_key = "YOUR_API_KEY"
    args = {"conf": 0.25, "iou": 0.7, "imgsz": 640}

    with open("image.jpg", "rb") as f:
        response = requests.post(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            data=args,
            files={"file": f},
        )

    print(response.json())
    ```

=== "cURL"

    ```bash
    curl -X POST "https://your-deployment-url.run.app/predict" \
      -H "Authorization: Bearer YOUR_API_KEY" \
      -F "file=@image.jpg" \
      -F "conf=0.25" \
      -F "iou=0.7" \
      -F "imgsz=640"
    ```

=== "JavaScript"

    ```javascript
    const form = new FormData();
    form.append("file", fileInput.files[0]);
    form.append("conf", "0.25");
    form.append("iou", "0.7");
    form.append("imgsz", "640");

    const response = await fetch("https://your-deployment-url.run.app/predict", {
        method: "POST",
        headers: { Authorization: "Bearer YOUR_API_KEY" },
        body: form,
    });

    const results = await response.json();
    console.log(results);
    ```

### Account Management

- **Teams & Organizations**: Collaborate with team members, manage roles and invites, and switch workspaces from the account menu
- **API Keys**: Secure key management for remote training and API access
- **Credits & Billing**: Pay-as-you-go training with transparent pricing and top-ups from $5 to $1,000
- **Activity Feed**: Track all account events and actions
- **Trash & Restore**: 30-day soft delete with item recovery
- **GDPR Compliance**: Data export and account deletion

!!! info "Plan Tiers"

    See the canonical [Free, Pro, and Enterprise comparison](account/billing.md#plans) for current limits, GPU access, collaboration, and licensing.

## Quick Links

Get started with these resources:

- [**Quickstart**](quickstart.md): Create your first project and train a model in minutes
- [**Explore**](explore.md): Browse and clone public datasets and projects, and search images by what they show
- [**Data**](data/index.md): Dataset preparation overview
- [**Datasets**](data/datasets.md): Upload and manage your training data
- [**Annotation**](data/annotation.md): Label your data with manual and AI-assisted tools
- [**Train**](train/index.md): Training overview
- [**Projects**](train/projects.md): Organize your models and experiments
- [**Models**](train/models.md): Model pages, downloads, and exports
- [**Cloud Training**](train/cloud-training.md): Train on cloud GPUs
- [**Deploy**](deploy/index.md): Deployment overview
- [**Inference**](deploy/inference.md): Test your models
- [**Endpoints**](deploy/endpoints.md): Deploy models to production
- [**Monitoring**](deploy/monitoring.md): Track deployment performance
- [**Account**](account/index.md): Account overview
- [**Settings**](account/settings.md): Profile and workspace preferences
- [**Teams**](account/teams.md): Members, roles, and invites
- [**API Keys**](account/api-keys.md): Manage API access
- [**Billing**](account/billing.md): Credits and payment
- [**Activity**](account/activity.md): Track account events
- [**Trash**](account/trash.md): Recover deleted items
- [**Integrations**](integrations/index.md): Cloud storage, annotation tools, and Slack
- [**REST API**](api/index.md): API reference

## Troubleshooting

### Dataset Issues

| Problem                | Solution                                                                                                                                                                                                      |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Dataset won't process  | Check file format is supported (JPEG, PNG, WebP, TIFF, HEIC, AVIF, BMP, JP2, DNG, MPO for images). Max file size: images 50 MB, videos 1 GB, dataset archives 10 GB (Free) / 20 GB (Pro) / 50 GB (Enterprise) |
| Missing annotations    | Verify labels are in [YOLO format](../datasets/detect/index.md#ultralytics-yolo-format) with `.txt` files matching image filenames, or upload COCO JSON                                                       |
| "Train split required" | Add `train/` folder to your dataset structure, or redistribute splits via the [split bar](data/datasets.md#split-redistribution)                                                                              |
| Class names undefined  | Add a `data.yaml` file with `names:` list (see [YOLO format](../datasets/detect/index.md#ultralytics-yolo-format)), or define classes in the [Classes tab](data/datasets.md#classes-tab)                      |

### Training Issues

| Problem              | Solution                                                                            |
| -------------------- | ----------------------------------------------------------------------------------- |
| Training won't start | Check credit balance in Settings > Billing. Positive balance required               |
| Out of memory error  | Reduce batch size, use smaller model (n/s), or select GPU with more VRAM            |
| Poor metrics         | Check dataset quality, increase epochs, try data augmentation, verify class balance |
| Training slow        | Select faster GPU, reduce image size, check dataset isn't bottlenecked              |

### Deployment Issues

| Problem                 | Solution                                                                                                                    |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| Endpoint not responding | Check endpoint status (Ready vs Stopped). A cold start after idle can take up to a minute on the first request              |
| 401 Unauthorized        | Verify the API key is active and copied correctly                                                                           |
| Slow inference          | Check model size, consider [TensorRT export](train/models.md#supported-formats), select closer region                       |
| Export failed           | Some formats require specific model architectures. Try [ONNX](train/models.md#supported-formats) for broadest compatibility |

### Common Questions

??? question "Can I change my username after signup?"

    No, usernames are permanent and cannot be changed. Choose carefully during signup.

??? question "Can I change my data region?"

    Your data region is selected during onboarding and can't be changed yourself. To switch regions, contact support to request a region change.

??? question "How do I get more credits?"

    Go to **Settings > Billing** and click **Top Up**. Purchase credits from $5 to $1,000. Purchased credits never
    expire.

??? question "What happens if training fails?"

    If cloud compute had started, elapsed GPU time is charged. Failures before a GPU starts have no compute usage
    charge.

??? question "Can I download my trained model?"

    Yes. Click the download icon on a model page for its `.pt` weights, or open the **Export** tab for completed exported formats.

??? question "How do I share my work publicly?"

    Open the project or dataset, click its **Private** badge in the top navigation bar, and confirm **Make public**.
    Public content appears on the Explore page.

??? question "What are the file size limits?"

    Images: 50MB, Videos: 1GB, datasets: 10GB on Free, 20GB on Pro, 50GB on Enterprise. For larger files, split into multiple uploads.

??? question "How long are deleted items kept in Trash?"

    30 days. After that, items are permanently deleted and cannot be recovered.

??? question "Can I use Platform models commercially?"

    Free and Pro plans use the AGPL license. For commercial use without AGPL requirements, see [Ultralytics Licensing](https://www.ultralytics.com/license).

## FAQ

### How do I get started with Ultralytics Platform?

To get started with [Ultralytics Platform](https://platform.ultralytics.com):

1. **Sign Up**: Create an account at [platform.ultralytics.com](https://platform.ultralytics.com)
2. **Select Region**: Choose your data region (US, EU, or AP) during onboarding
3. **Upload Dataset**: Open `Annotate` in the sidebar and upload your data
4. **Train Model**: Create a project and start training on cloud GPUs
5. **Deploy**: Test your model and deploy to a dedicated endpoint

For a detailed guide, see the [Quickstart](quickstart.md) page.

### What are the benefits of Ultralytics Platform?

[Ultralytics Platform](https://platform.ultralytics.com) offers:

- **Unified Workflow**: Data, training, and deployment in one place
- **Multi-Region**: Data residency in US, EU, or AP regions
- **No-Code Training**: Train advanced YOLO models without writing code
- **Real-Time Metrics**: Stream training progress and monitor deployments
- **42 Deploy Regions**: Deploy models close to your users worldwide
- **7 Task Types**: Support for detection, instance segmentation, semantic segmentation, depth estimation, classification, pose, and OBB (see [task docs](../tasks/index.md))
- **AI-Assisted Annotation**: [Smart annotation](data/annotation.md#smart-annotation) with SAM, YOLO, and class-prompted models (detection datasets with 1–200 classes) to speed up data preparation

### What GPU options are available for cloud training?

Ultralytics Platform supports multiple GPU types for cloud training:

{% include "macros/platform-gpu-table.md" %}

See [Cloud Training](train/cloud-training.md) for complete pricing and GPU options.

### How does remote training work?

You can train models on your own hardware and stream real-time metrics to Ultralytics Platform.

!!! warning "Package Version Requirement"

    Platform integration requires **Python>=3.11** and **ultralytics>=8.4.120**. Lower versions will NOT work with Platform.

    ```bash
    pip install "ultralytics>=8.4.120"
    ```

=== "CLI"

    ```bash
    # Set your API key
    export ULTRALYTICS_API_KEY="YOUR_API_KEY"

    # Train with project/name to stream metrics
    yolo train model=yolo26n.pt data=coco.yaml epochs=100 project=username/my-project name=exp1
    ```

=== "Python"

    ```python
    import os

    from ultralytics import YOLO

    os.environ["ULTRALYTICS_API_KEY"] = "YOUR_API_KEY"

    model = YOLO("yolo26n.pt")
    model.train(
        data="coco.yaml",
        epochs=100,
        project="username/my-project",
        name="exp1",
    )
    ```

=== "Platform Dataset (ul:// URI)"

    ```bash
    # Train using a Platform dataset directly
    export ULTRALYTICS_API_KEY="YOUR_API_KEY"

    yolo train model=yolo26n.pt data=ul://username/datasets/my-dataset epochs=100 project=username/my-project name=exp1
    ```

See [Cloud Training](train/cloud-training.md#remote-training) for more details on remote training.

### What annotation tools are available?

The Platform includes a full-featured annotation editor supporting:

- **Manual Tools**: Bounding boxes, polygons, keypoints with skeleton templates, oriented boxes, classification
- **Skeleton Templates**: Place all keypoints at once using built-in (Person, Hand, Dog, Face, Box) or custom templates
- **Smart Annotation**: Use [SAM 2.1](../models/sam-2.md), [SAM 3](../models/sam-3.md), or [SAM 3.1](../models/sam-3.md#sam-31) (default) for click-based annotation on detect, segment, semantic, and OBB datasets, run pretrained Ultralytics YOLO models and your own fine-tuned YOLO models from the toolbar for those tasks and pose, or run class-prompted models on detection datasets with 1–200 classes: six hosted open-source models (Moondream 3.1 by default), hosted text-prompted SAM 3 and SAM 3.1, or paid vision models from OpenAI, Anthropic, Google, Meta, SpaceXAI, DeepSeek, Z.ai, Kimi, and Xiaomi MiMo with a provider key from **Settings > API Keys**
- **Keyboard Shortcuts**: Efficient workflows with hotkeys, listed in the editor's shortcuts popover

| Shortcut                            | Action                                          |
| ----------------------------------- | ----------------------------------------------- |
| `V`                                 | Manual (draw) mode                              |
| `S`                                 | Smart mode (SAM, YOLO, or class-prompted model) |
| `P`                                 | Predict (in Smart mode)                         |
| `A`                                 | Toggle auto-apply (SAM Smart mode)              |
| `1` - `9`                           | Select class by number                          |
| `H`                                 | Toggle annotation visibility                    |
| `Space` + drag or middle-click drag | Pan the canvas                                  |
| `Delete` / `Backspace`              | Delete selected annotation                      |
| `Ctrl+S`                            | Save annotations                                |
| `Ctrl+Z`                            | Undo                                            |
| `Ctrl+Y`                            | Redo                                            |
| `Escape`                            | Save / deselect / exit                          |

See [Annotation](data/annotation.md) for the complete guide.

### What export formats are supported?

The Platform supports the same 22 deployment formats as Ultralytics Export mode. PyTorch is the source format; each row with a `format` argument is an export target.

{% include "macros/export-table.md" %}

See [Models Export](train/models.md#export-model), the [Export mode guide](../modes/export.md), and the [Integrations index](../integrations/index.md) for format-specific options.

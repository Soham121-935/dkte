---
plans: [free, pro, enterprise]
title: Model Deployment Options
comments: true
description: Learn about model deployment options in Ultralytics Platform including inference testing, dedicated endpoints, and monitoring dashboards.
keywords: Ultralytics Platform, deployment, inference, endpoints, monitoring, YOLO, production, cloud deployment
---

# Deployment

[Ultralytics Platform](https://platform.ultralytics.com) provides comprehensive [model deployment options](../../guides/model-deployment-options.md) for putting your YOLO models into production. Test models with browser-based inference, deploy to dedicated endpoints across 42 global regions, and monitor performance in real-time.

<p align="center">
  <br>
  <iframe loading="lazy" width="720" height="405" src="https://www.youtube.com/embed/JjgQYPetX8w"
    title="YouTube video player" frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowfullscreen>
  </iframe>
  <br>
  <strong>Watch:</strong> Get Started with Ultralytics Platform - Deploy
</p>

## Overview

The Deployment section helps you:

- **Test** models directly in the browser with the `Predict` tab
- **Deploy** to dedicated endpoints in 42 global regions
- **Monitor** request metrics, logs, health checks, and temporary predictions on every dedicated endpoint
- **Choose resources**: default endpoints scale to zero; custom sizes keep a warm instance with uptime billing

![Ultralytics Platform Deployments Tab World Map With Overview Cards](https://cdn.ul.run/i/61603cb9902cf112660c2a5d2fb5bc44.avif)<!-- screenshot -->

## Deployment Options

Ultralytics Platform offers multiple deployment paths:

| Option                                        | Description                                              | Best For                |
| --------------------------------------------- | -------------------------------------------------------- | ----------------------- |
| **[Predict Tab](inference.md)**               | Image, webcam, examples; IP camera on own endpoints      | Development, validation |
| **Shared Inference**                          | Multi-tenant service across 3 data regions               | Light usage, testing    |
| **[Dedicated Endpoints](endpoints.md)**       | Single-tenant services across 42 regions                 | Production, low latency |
| **[Export](../train/models.md#export-model)** | Download weights in 22 formats for local or edge runtime | Offline, on-device      |

## Workflow

```mermaid
flowchart TD
    A([Test]) --> B[Configure]
    B --> C[Deploy]
    C --> D([Monitor])
```

| Stage         | Description                                                                       |
| ------------- | --------------------------------------------------------------------------------- |
| **Test**      | Validate model with the [`Predict` tab](inference.md)                             |
| **Configure** | Select a model, region, CPU, and memory; review pricing and the deployment name   |
| **Deploy**    | Create a dedicated endpoint from the [`Deploy` tab](endpoints.md)                 |
| **Monitor**   | Inspect endpoint metrics and temporary predictions in [Monitoring](monitoring.md) |

## Architecture

### Shared Inference

The shared inference service runs in 3 key regions. Requests to a model are routed to the service in that model's
[data region](../account/settings.md), so results stay inside the region where the model is stored:

```mermaid
flowchart TD
    A([User request]) --> B[Platform API]
    B --> C{Model data region?}
    C -->|US| D[Iowa]
    C -->|EU| E[Belgium]
    C -->|AP| F[Taiwan]
```

{% include "macros/platform-data-regions.md" %}

### Dedicated Endpoints

Deploy to 42 regions worldwide on Ultralytics Cloud:

- **Americas**: 14 regions
- **Europe**: 13 regions
- **Asia-Pacific**: 12 regions
- **Middle East & Africa**: 3 regions

Each endpoint is a single-tenant service with:

- Configurable CPU and memory with pricing shown before deployment
- Scale-to-zero for default resources; a warm, uptime-billed instance for custom resources
- Unique endpoint URL with its own interactive API reference at `/docs`
- Its own API key binding, so only that key can call the endpoint
- Independent monitoring, logs, and health checks

## Deployments Tab

All your deployments are listed on the **Deployments** tab of your profile (`/{username}?tab=deployments`), next to
Datasets and Projects. The sidebar's **Deployments** section lists your deployments, each linking to its deployment
page, with a `+` button to create one and a link to the full tab. The tab shows:

- **World map** with deployed region pins; click a region to open the `New Deployment` dialog
- **Overview cards**: Active Deployments, HTTP Requests (24h), HTTP Error Rate (24h), HTTP P95 Latency (24h)
- **Deployments list** with search, sorting, and three view modes: cards, compact, and table; each deployment links to
  its own page with `Overview`, `Monitoring`, `Predict`, and `Logs` tabs
- **New Deployment** button to create endpoints from any completed model

![Ultralytics Platform Deployments Tab Overview Cards And Deployments List](https://cdn.ul.run/i/b46672351aac3f3b75e8359a819e941e.avif)<!-- screenshot -->

!!! info "Automatic Polling"

    The tab refreshes automatically, and faster while a deployment is changing state (`creating`, `deploying`, or `stopping`). See [Monitoring](monitoring.md) for details.

!!! warning "Lightweight, Temporary Monitoring"

    Every ready dedicated endpoint provides charts and example images held only in the serving instance's memory. Stopping, restarting, redeploying, resizing, or replacing the model can clear this data. Save examples to a dataset and wait for ingestion to finish to keep them. See [Monitoring](monitoring.md#monitoring-tab).

## Key Features

### Global Coverage

Deploy close to your users with 42 regions covering:

- North America, South America
- Europe, Middle East, Africa
- Asia Pacific, Oceania

### Scaling Behavior

Endpoints currently behave as follows:

- **Default resources**: idle endpoints scale down to zero and cold-start on the next request
- **Custom resources**: one instance stays warm and accrues uptime charges until stopped
- **Single active instance**: each endpoint currently serves from one instance on all plans
- **Load shedding**: requests receive `429` responses when the endpoint is temporarily at capacity — see [Direct Endpoint Requests](endpoints.md#direct-endpoint-requests)
- **Request timeout**: direct endpoint requests have a maximum duration of 1 hour; see [Inference](inference.md) for supported inputs

### Regional Deployment

Use the measured region latency to place an endpoint near its callers. Actual inference latency depends on the model,
input size, endpoint state, and network path.

### Health Checks

Each running deployment includes an automatic health check with:

- Live status indicator (healthy/unhealthy)
- Response latency display
- Auto-retry when unhealthy, stopping once healthy
- Manual re-ping button

## Quick Start

Create a deployment:

1. Train or upload a model to a project
2. Go to the model's **Deploy** tab
3. Click **Deploy** for a region in the latency table
4. Review CPU, memory, pricing, and name in the deployment dialog
5. Click **Create Deployment** and wait for the deployment status to become **Ready**

!!! example "Quick Deploy"

    ```text
    Model → Deploy tab → Deploy in a region → Review configuration → Create Deployment
    ```

    The deployment name is generated from the model name and region city and can be edited before deployment. Once deployed, use the endpoint URL with your API key to send inference requests from any application.

## Quick Links

- [**Inference**](inference.md): Test models in browser
- [**Endpoints**](endpoints.md): Deploy dedicated endpoints
- [**Monitoring**](monitoring.md): Track deployment performance

## FAQ

### What's the difference between shared and dedicated inference?

| Feature         | Shared                       | Dedicated                                   |
| --------------- | ---------------------------- | ------------------------------------------- |
| **Service**     | Shared across Platform users | Dedicated to one deployment                 |
| **Scale**       | Managed by Platform          | Default: scales to zero; custom: stays warm |
| **Regions**     | 3 data regions               | Choose from 42 deployment regions           |
| **URL**         | Platform model API           | Generated deployment endpoint URL           |
| **Testing**     | Model `Predict` tab          | Deployment page `Predict` tab or API        |
| **Rate limits** | 20 requests/minute           | No Platform rate limit on direct calls      |
| **Auth**        | Any workspace API key        | Only the API key bound to the deployment    |

### How long does deployment take?

The deployment remains in a creating or deploying state while its service starts. It becomes usable when the status
changes to **Ready**; timing varies by model and region, and typically takes a few minutes.

### Can I deploy multiple models?

Yes, each model can have multiple endpoints in different regions. Deployment counts are limited by plan: Free `3`, Pro
`10`, Enterprise `unlimited`. The quota is charged to the workspace that owns the model, and an endpoint serves exactly
one model at a time — use [model replacement](endpoints.md#replace-a-model) to swap it without changing the URL.

### What happens when an endpoint is idle?

Default-resource endpoints scale to zero when idle:

- Endpoint scales down after inactivity
- First request triggers cold start
- Subsequent requests are fast

First requests after an idle period trigger a cold start. Opening the deployment page runs a health check that warms
the endpoint, so a test prediction right after it responds quickly.

Custom-resource endpoints stay warm and are charged for uptime, including idle time. Stop an endpoint to stop its uptime charge.

---
comments: true
license:
    name: CC-BY-4.0
    url: https://creativecommons.org/licenses/by/4.0/
description: Explore the iBims-1 indoor benchmark for monocular depth estimation. Learn about its structure, usage, pretrained models, and role as a YOLO26-Depth zero-shot evaluation benchmark.
keywords: Ultralytics, YOLO, depth estimation, iBims-1, indoor depth, laser scanner, monocular depth, depth edges, planar surfaces
---

# iBims-1 Depth Dataset

[iBims-1](https://www.asg.ed.tum.de/lmf/ibims1/) (independent Benchmark images and matched scans) is a high-quality indoor benchmark for [monocular depth estimation](index.md). It pairs RGB images with survey-grade laser-scanner ground truth and is designed to test sharp depth edges and planar surfaces.

## Key Features

- High-quality depth ground truth captured with a survey-grade laser scanner.
- Covers real **indoor** scenes.
- Depth range up to approximately 10 m.
- Evaluation is performed on 100 images.
- Specifically designed to evaluate sharp depth edges and the quality of planar surfaces.

## Role in YOLO26-Depth

iBims-1 is a **zero-shot evaluation benchmark** for the YOLO26-Depth family; the published models are not trained on it. Its focus on sharp depth discontinuities and planar regions makes it a precise test of depth-map quality beyond aggregate accuracy.

Evaluation uses multi-scale and horizontal-flip test-time augmentation (TTA), followed by log-least-squares scale alignment between the predicted and ground-truth depth maps before metrics are computed.

## Results

The table below reports the `delta1` accuracy (fraction of pixels within a 1.25× threshold, higher is better) on the iBims-1 evaluation images by model size.

| Model         | delta1 |
| ------------- | ------ |
| YOLO26n-depth | 0.923  |
| YOLO26s-depth | 0.899  |
| YOLO26m-depth | 0.953  |
| YOLO26l-depth | 0.952  |
| YOLO26x-depth | 0.961  |

## Evaluation

iBims-1 is not shipped with a bundled dataset YAML. It is evaluated through a dedicated evaluation script that loads the iBims-1 images and laser-scanner depth ground truth, applies the standard TTA and log-least-squares scale alignment, and reports the depth metrics.

## Usage

iBims-1 is an external benchmark, so models are typically run with `predict` on its images. For a comprehensive list of available arguments, refer to the model [Prediction](../../modes/predict.md) page.

!!! example "Predict Example"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load a model
        model = YOLO("yolo26x-depth.pt")  # load a pretrained depth model

        # Predict depth on iBims-1 images
        results = model.predict("path/to/ibims1/images")
        ```

    === "CLI"

        ```bash
        # Predict depth with a pretrained *.pt model
        yolo depth predict model=yolo26x-depth.pt source=path/to/ibims1/images
        ```

## Pretrained Models

The YOLO26 depth family is evaluated zero-shot on the iBims-1 benchmark. These models auto-download on first use from the Ultralytics [v8.4.0 assets release](https://github.com/ultralytics/assets/releases/tag/v8.4.0), for example [YOLO26x-depth](https://platform.ultralytics.com/ultralytics/yolo26/yolo26x-depth), and span a range of sizes (yolo26n/s/m/l/x-depth) for different accuracy and resource requirements.

## Citations and Acknowledgments

If you use the iBims-1 dataset in your research or development work, please cite the following paper:

!!! quote ""

    === "BibTeX"

        ```bibtex
        @inproceedings{koch2018ibims,
              title={Evaluation of CNN-based Single-Image Depth Estimation Methods},
              author={Koch, Tobias and Liebel, Lukas and Fraundorfer, Friedrich and K{\"o}rner, Marco},
              booktitle={Proceedings of the European Conference on Computer Vision (ECCV) Workshops},
              year={2018}
        }
        ```

We would like to acknowledge the authors for creating and maintaining this valuable resource for the computer vision community.

## FAQ

### What does iBims-1 evaluate?

iBims-1 is a 100-image indoor benchmark with survey-grade laser-scanner depth designed to test sharp depth edges and planar surfaces, going beyond aggregate accuracy to probe depth-map quality. The YOLO26-Depth models are evaluated on it zero-shot, with YOLO26x-depth reaching a delta1 of 0.961.

### Can I validate on iBims-1 with a dataset YAML?

No. iBims-1 ships without a bundled YAML and is scored through a dedicated evaluation script with multi-scale and flip test-time augmentation and log-least-squares scale alignment. Use [predict mode](../../modes/predict.md) on its images as shown in the [Usage](#usage) section.

### What other benchmarks are used alongside iBims-1?

The released models are also evaluated zero-shot on [NYU Depth V2](nyu-depth-v2.md), [ETH3D](eth3d.md), and [Make3D](make3d.md), and on the [KITTI Eigen](kitti.md) split, whose training drives are part of the pretraining mix; see the [Depth Estimation task page](../../tasks/depth.md) for the combined results.

---
title: Export YOLO26 to PaddlePaddle Format
comments: true
description: Learn how to export YOLO26 models to PaddlePaddle format for enhanced performance, flexibility, and deployment across various platforms and devices.
keywords: YOLO26, PaddlePaddle, export models, computer vision, deep learning, model deployment, performance optimization
---

# How to Export to PaddlePaddle Format from YOLO26 Models

Bridging the gap between developing and deploying [computer vision](https://www.ultralytics.com/glossary/computer-vision-cv) models in real-world scenarios with varying conditions can be difficult. PaddlePaddle makes this process easier with its focus on flexibility, performance, and its capability for parallel processing in distributed environments. This means you can use your YOLO26 computer vision models on a wide variety of devices and platforms, from smartphones to cloud-based servers.

<p align="center">
  <br>
  <iframe loading="lazy" width="720" height="405" src="https://www.youtube.com/embed/c5eFrt2KuzY"
    title="YouTube video player" frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowfullscreen>
  </iframe>
  <br>
  <strong>Watch:</strong> How to Export Ultralytics YOLO26 Models to PaddlePaddle Format | Key Features of PaddlePaddle Format
</p>

The ability to export to PaddlePaddle model format allows you to optimize your [Ultralytics YOLO26](https://github.com/ultralytics/ultralytics) models for use within the PaddlePaddle framework. PaddlePaddle is known for facilitating industrial deployments and is a good choice for deploying computer vision applications in real-world settings across various domains.

## Why should you export to PaddlePaddle?

<p align="center">
  <img width="75%" src="https://github.com/PaddlePaddle/Paddle/blob/develop/doc/imgs/logo.png?raw=true" alt="PaddlePaddle deep learning framework logo">
</p>

Developed by Baidu, [PaddlePaddle](https://www.paddlepaddle.org.cn/en) (**PA**rallel **D**istributed **D**eep **LE**arning) is China's first open-source [deep learning](https://www.ultralytics.com/glossary/deep-learning-dl) platform. Unlike some frameworks built mainly for research, PaddlePaddle prioritizes ease of use and smooth integration across industries.

It offers tools and resources similar to popular frameworks like [TensorFlow](https://www.ultralytics.com/glossary/tensorflow) and [PyTorch](https://www.ultralytics.com/glossary/pytorch), making it accessible for developers of all experience levels. From farming and factories to service businesses, PaddlePaddle's large developer community of over 4.77 million is helping create and deploy AI applications.

By exporting your Ultralytics YOLO26 models to PaddlePaddle format, you can tap into PaddlePaddle's strengths in performance optimization. PaddlePaddle prioritizes efficient model execution and reduced memory usage. As a result, your YOLO26 models can potentially achieve even better performance, delivering top-notch results in practical scenarios.

## Key Features of PaddlePaddle Models

PaddlePaddle models offer a range of key features that contribute to their flexibility, performance, and scalability across diverse deployment scenarios:

- **Dynamic-to-Static Graph**: PaddlePaddle supports [dynamic-to-static compilation](https://www.paddlepaddle.org.cn/documentation/docs/en/guides/jit/index_en.html), where models can be translated into a static computational graph. This enables optimizations that reduce runtime overhead and boost inference performance.

- **Operator Fusion**: PaddlePaddle, like [TensorRT](../integrations/tensorrt.md), uses [operator fusion](https://developer.nvidia.com/gtc/2020/video/s21436-vid) to streamline computation and reduce overhead. The framework minimizes memory transfers and computational steps by merging compatible operations, resulting in faster inference.

- **Quantization**: PaddlePaddle supports [quantization techniques](https://www.paddlepaddle.org.cn/documentation/docs/en/api/paddle/quantization/PTQ_en.html), including post-training quantization and quantization-aware training. These techniques allow for the use of lower-precision data representations, effectively boosting performance and reducing model size.

## Deployment Options in PaddlePaddle

Before diving into the code for exporting YOLO26 models to PaddlePaddle, let's take a look at the different deployment scenarios in which PaddlePaddle models excel.

PaddlePaddle provides a range of options, each offering a distinct balance of ease of use, flexibility, and performance:

- **Paddle Serving**: This framework simplifies the deployment of PaddlePaddle models as high-performance RESTful APIs. Paddle Serving is ideal for production environments, providing features like model versioning, online A/B testing, and scalability for handling large volumes of requests.

- **Paddle Inference API**: The Paddle Inference API gives you low-level control over model execution. This option is well-suited for scenarios where you need to integrate the model tightly within a custom application or optimize performance for specific hardware.

- **Paddle Lite**: Paddle Lite is designed for deployment on mobile and embedded devices where resources are limited. It optimizes models for smaller sizes and faster inference on ARM CPUs, GPUs, and other specialized hardware.

- **Paddle.js**: Paddle.js enables you to deploy PaddlePaddle models directly within web browsers. Paddle.js can either load a pretrained model or transform a model from [paddle-hub](https://github.com/PaddlePaddle/PaddleHub) with model transforming tools provided by Paddle.js. It can run in browsers that support WebGL/WebGPU/WebAssembly.

## Supported Tasks

PaddlePaddle export supports all seven Ultralytics tasks. Semantic segmentation and depth estimation are available only with YOLO26, the only family that ships those heads.

{% include "macros/supported-tasks.md" %}

## Export to PaddlePaddle: Converting Your YOLO26 Model

Converting YOLO26 models to the PaddlePaddle format can improve execution flexibility and optimize performance for various deployment scenarios.

### Installation

To install the required package, run:

!!! tip "Installation"

    === "CLI"

        ```bash
        # Install the required package for YOLO26
        pip install ultralytics
        ```

For detailed instructions and best practices related to the installation process, check our [Ultralytics Installation guide](../quickstart.md). While installing the required packages for YOLO26, if you encounter any difficulties, consult our [Common Issues guide](../guides/yolo-common-issues.md) for solutions and tips.

### Usage

All [Ultralytics YOLO26 models](../models/yolo26.md) support export, and you can [browse the full list of export formats and options](../modes/export.md) to find the best fit for your deployment needs.

The PaddlePaddle format supports the [Export](../modes/export.md), [Predict](../modes/predict.md), and [Validate](../modes/val.md) modes. Export your model, then load the exported model to run inference or validate its accuracy.

!!! example "Export"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load a YOLO26 model
        model = YOLO("yolo26n.pt")

        # Export the model to PaddlePaddle format
        model.export(format="paddle")  # creates 'yolo26n_paddle_model'
        ```

    === "CLI"

        ```bash
        # Export a YOLO26n PyTorch model to PaddlePaddle format
        yolo export model=yolo26n.pt format=paddle # creates 'yolo26n_paddle_model'
        ```

!!! example "Predict"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load the exported PaddlePaddle model
        model = YOLO("./yolo26n_paddle_model")

        # Run inference
        results = model("https://ultralytics.com/images/bus.jpg")
        ```

    === "CLI"

        ```bash
        # Run inference with the exported PaddlePaddle model
        yolo predict model=./yolo26n_paddle_model source='https://ultralytics.com/images/bus.jpg'
        ```

!!! example "Validate"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load the exported PaddlePaddle model
        model = YOLO("./yolo26n_paddle_model")

        # Validate accuracy on the COCO8 dataset
        metrics = model.val(data="coco8.yaml")
        ```

    === "CLI"

        ```bash
        # Validate the exported PaddlePaddle model
        yolo val model=./yolo26n_paddle_model data=coco8.yaml
        ```

### Export Arguments

| Argument   | Type             | Default    | Description                                                                                                                             |
| ---------- | ---------------- | ---------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| `format`   | `str`            | `'paddle'` | Target format for the exported model, defining compatibility with various deployment environments.                                      |
| `imgsz`    | `int` or `tuple` | `640`      | Desired image size for the model input. Can be an integer for square images or a tuple `(height, width)` for specific dimensions.       |
| `quantize` | `int` or `str`   | `None`     | Fixed FP32 export. PaddlePaddle export does not support export-time FP16, INT8, or W8A16 precision conversion.                          |
| `batch`    | `int`            | `1`        | Specifies export model batch inference size or the max number of images the exported model will process concurrently in `predict` mode. |
| `device`   | `str`            | `None`     | Specifies the device for exporting: CPU (`device=cpu`), MPS for Apple silicon (`device=mps`).                                           |

For more details about the export process, visit the [Ultralytics documentation page on exporting](../modes/export.md).

## Deploying Exported YOLO26 PaddlePaddle Models

After successfully exporting your Ultralytics YOLO26 models to PaddlePaddle format, you can now deploy them. The primary and recommended first step for running a PaddlePaddle model is to use the YOLO("yolo26n_paddle_model/") method, as outlined in the previous usage code snippet.

However, for in-depth instructions on deploying your PaddlePaddle models in various other settings, take a look at the following resources:

- **[Paddle Serving](https://github.com/PaddlePaddle/Serving/blob/v0.9.0/README_CN.md)**: Learn how to deploy your PaddlePaddle models as performant services using Paddle Serving.

- **[Paddle Lite](https://github.com/PaddlePaddle/Paddle-Lite/blob/develop/README_en.md)**: Explore how to optimize and deploy models on mobile and embedded devices using Paddle Lite.

- **[Paddle.js](https://paddlejs.baidu.com)**: Discover how to run PaddlePaddle models in web browsers for client-side AI using Paddle.js.

## Summary

In this guide, we explored the process of exporting Ultralytics YOLO26 models to the PaddlePaddle format. By following these steps, you can leverage PaddlePaddle's strengths in diverse deployment scenarios, optimizing your models for different hardware and software environments.

For further details on usage, visit the [PaddlePaddle official documentation](https://www.paddlepaddle.org.cn/documentation/docs/en/guides/index_en.html).

Want to explore more ways to integrate your Ultralytics YOLO26 models? Our [integration guide page](index.md) explores various options, equipping you with valuable resources and insights.

## FAQ

### How do I export Ultralytics YOLO26 models to PaddlePaddle format?

Exporting Ultralytics YOLO26 models to PaddlePaddle format is straightforward. You can use the `export` method of the YOLO class to perform the conversion. Here is an example using Python:

!!! example "Usage"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load a YOLO26 model
        model = YOLO("yolo26n.pt")

        # Export the model to PaddlePaddle format
        model.export(format="paddle")  # creates 'yolo26n_paddle_model'

        # Load the exported PaddlePaddle model
        paddle_model = YOLO("./yolo26n_paddle_model")

        # Run inference
        results = paddle_model("https://ultralytics.com/images/bus.jpg")
        ```

    === "CLI"

        ```bash
        # Export a YOLO26n PyTorch model to PaddlePaddle format
        yolo export model=yolo26n.pt format=paddle # creates 'yolo26n_paddle_model'

        # Run inference with the exported model
        yolo predict model='./yolo26n_paddle_model' source='https://ultralytics.com/images/bus.jpg'
        ```

For more detailed setup and troubleshooting, check the [Ultralytics Installation Guide](../quickstart.md) and [Common Issues Guide](../guides/yolo-common-issues.md).

### What are the advantages of using PaddlePaddle for [model deployment](https://www.ultralytics.com/glossary/model-deployment)?

PaddlePaddle offers several key advantages for model deployment:

- **Performance Optimization**: PaddlePaddle excels in efficient model execution and reduced memory usage.
- **Dynamic-to-Static Graph Compilation**: It supports dynamic-to-static compilation, allowing for runtime optimizations.
- **Operator Fusion**: By merging compatible operations, it reduces computational overhead.
- **Quantization Techniques**: Supports both post-training and quantization-aware training, enabling lower-[precision](https://www.ultralytics.com/glossary/precision) data representations for improved performance.

You can achieve enhanced results by exporting your Ultralytics YOLO26 models to PaddlePaddle, ensuring flexibility and high performance across various applications and hardware platforms. Explore PaddlePaddle's key features and capabilities in the [official PaddlePaddle documentation](https://www.paddlepaddle.org.cn/en).

### Why should I choose PaddlePaddle for deploying my YOLO26 models?

PaddlePaddle, developed by Baidu, is optimized for industrial and commercial AI deployments. Its large developer community and robust framework provide extensive tools similar to TensorFlow and PyTorch. By exporting your YOLO26 models to PaddlePaddle, you leverage:

- **Enhanced Performance**: Optimal execution speed and reduced memory footprint.
- **Flexibility**: Wide compatibility with various devices from smartphones to cloud servers.
- **Scalability**: Efficient parallel processing capabilities for distributed environments.

These features make PaddlePaddle a compelling choice for deploying YOLO26 models in production settings.

### How does PaddlePaddle improve model performance over other frameworks?

PaddlePaddle employs several advanced techniques to optimize model performance:

- **Dynamic-to-Static Graph**: Converts models into a static computational graph for runtime optimizations.
- **Operator Fusion**: Combines compatible operations to minimize memory transfer and increase inference speed.
- **Quantization**: Reduces model size and increases efficiency using lower-precision data while maintaining [accuracy](https://www.ultralytics.com/glossary/accuracy).

These techniques prioritize efficient model execution, making PaddlePaddle an excellent option for deploying high-performance YOLO26 models. For more on optimization, see the [PaddlePaddle official documentation](https://www.paddlepaddle.org.cn/documentation/docs/en/guides/index_en.html).

### What deployment options does PaddlePaddle offer for YOLO26 models?

PaddlePaddle provides flexible deployment options:

- **Paddle Serving**: Deploys models as RESTful APIs, ideal for production with features like model versioning and online A/B testing.
- **Paddle Inference API**: Gives low-level control over model execution for custom applications.
- **Paddle Lite**: Optimizes models for mobile and embedded devices' limited resources.
- **Paddle.js**: Enables deploying models directly within web browsers.

These options cover a broad range of deployment scenarios, from on-device inference to scalable cloud services. Explore more deployment strategies on the [Ultralytics Model Deployment Options page](../guides/model-deployment-options.md).

"""Server-side Firestore mirror for accepted hardware telemetry.

The SQL database remains the application's operational source of truth. This
adapter mirrors real device readings to Firestore for cloud access and backup;
the Firebase service-account key is never returned by an API or sent to a
device/browser. Firestore outages do not block control or telemetry ingest.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import get_settings

log = logging.getLogger(__name__)
_APP_NAME = "myco-ai-firestore"


class FirestoreTelemetryMirror:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._app = None
        self._client = None
        self._queue: asyncio.Queue[dict[str, Any]] | None = None
        self._worker: asyncio.Task | None = None
        self._state: dict[str, Any] = {
            "connected": None,
            "checking": False,
            "last_success_at": None,
            "last_error": None,
        }

    def _configuration(self) -> tuple[bool, str, str, str]:
        settings = get_settings()
        path = str(Path(settings.firebase_credentials_path).expanduser()) if settings.firebase_credentials_path else ""
        project = settings.firebase_project_id.strip()
        configured = bool(settings.firebase_enabled and project and path and Path(path).is_file())
        if not settings.firebase_enabled:
            detail = "Firebase telemetry sync is disabled."
        elif not project:
            detail = "Set FIREBASE_PROJECT_ID in the backend environment."
        elif not path:
            detail = "Set FIREBASE_CREDENTIALS_PATH to the server-side service-account JSON file."
        elif not Path(path).is_file():
            detail = "The configured Firebase service-account file was not found."
        else:
            detail = "Connecting to Firestore."
        return settings.firebase_enabled, project, path, detail

    def status(self) -> dict[str, Any]:
        enabled, project, _path, detail = self._configuration()
        configured = bool(enabled and project and _path and Path(_path).is_file())
        with self._lock:
            state = dict(self._state)
        if configured:
            if state["connected"] is True:
                detail = "Connected; hardware telemetry is mirrored to Firestore."
            elif state["connected"] is False:
                detail = f"Firestore connection failed ({state['last_error'] or 'unknown error'})."
            else:
                detail = "Credentials are configured; checking Firestore connection."
        return {
            "enabled": enabled,
            "configured": configured,
            "connected": state["connected"] if configured else False,
            "checking": bool(configured and state["checking"]),
            "project_id": project or None,
            "detail": detail,
            "last_success_at": state["last_success_at"],
            "pending_writes": self._queue.qsize() if self._queue is not None else 0,
        }

    def _get_client(self):
        enabled, project, path, _ = self._configuration()
        if not enabled or not project or not path or not Path(path).is_file():
            raise RuntimeError("Firebase is not configured")
        with self._lock:
            if self._client is not None:
                return self._client
            import firebase_admin
            from firebase_admin import credentials, firestore

            try:
                app = firebase_admin.get_app(_APP_NAME)
            except ValueError:
                cert = credentials.Certificate(path)
                if getattr(cert, "project_id", project) != project:
                    raise ValueError("service account project does not match FIREBASE_PROJECT_ID")
                app = firebase_admin.initialize_app(
                    cert,
                    options={"projectId": project},
                    name=_APP_NAME,
                )
            self._app = app
            self._client = firestore.client(app=app)
            return self._client

    def _ping(self) -> None:
        client = self._get_client()
        # Reading a stable health document is a no-op even if it does not exist.
        client.collection("_myco_ai_health").document("firestore").get(timeout=5)

    async def start(self) -> None:
        enabled, _project, _path, _detail = self._configuration()
        if not enabled:
            return
        if self._queue is None:
            self._queue = asyncio.Queue(maxsize=2000)
        if self._worker is None or self._worker.done():
            self._worker = asyncio.create_task(self._run(), name="firestore-telemetry-mirror")
        asyncio.create_task(self.check_connection(), name="firestore-health-check")

    async def stop(self) -> None:
        if self._worker is not None:
            self._worker.cancel()
            try:
                await self._worker
            except asyncio.CancelledError:
                pass
            self._worker = None

    def enqueue_reading(self, reading: dict[str, Any]) -> None:
        status = self.status()
        if not status["configured"] or self._queue is None:
            return
        if reading.get("source") != "hardware":
            return
        self._enqueue({"kind": "telemetry", "data": dict(reading)})

    def enqueue_batch(self, batch: dict[str, Any]) -> None:
        """Queue a user-created cultivation batch for the Firestore mirror."""
        if not self.status()["configured"] or self._queue is None or batch.get("is_demo"):
            return
        self._enqueue({"kind": "batch", "data": dict(batch)})

    def enqueue_batch_delete(self, batch_id: int) -> None:
        """Queue removal of a deleted cultivation batch from Firestore."""
        if not self.status()["configured"] or self._queue is None:
            return
        self._enqueue({"kind": "batch_delete", "batch_id": int(batch_id)})

    def _enqueue(self, item: dict[str, Any]) -> None:
        assert self._queue is not None
        try:
            self._queue.put_nowait(item)
        except asyncio.QueueFull:
            with self._lock:
                self._state["connected"] = False
                self._state["last_error"] = "local_queue_full"
            log.warning("Firestore mirror queue is full; dropping a %s update", item.get("kind", "unknown"))

    def _write_reading(self, reading: dict[str, Any]) -> None:
        from google.cloud import firestore

        client = self._get_client()
        device_id = str(reading["device_id"])
        message_id = str(reading.get("message_id") or reading.get("id") or "unknown")
        safe_id = hashlib.sha256(f"{device_id}:{message_id}".encode("utf-8")).hexdigest()
        synced_at = datetime.now(timezone.utc)
        latest = {
            key: reading.get(key)
            for key in (
                "device_id", "measured_at", "received_at", "message_id", "schema_version", "source",
                "temperature_c", "relative_humidity_percent", "substrate_moisture_raw", "fan_state",
                "heater_state", "humidifier_state", "quality",
            )
        }
        latest["synced_at"] = synced_at
        device_ref = client.collection("myco_devices").document(device_id)
        reading_ref = device_ref.collection("telemetry").document(safe_id)
        batch = client.batch()
        batch.set(reading_ref, latest)
        batch.set(device_ref, {"device_id": device_id, "last_reading": latest, "updated_at": synced_at}, merge=True)
        batch.commit(timeout=5)

    def _write_batch(self, batch_data: dict[str, Any]) -> None:
        client = self._get_client()
        batch_id = batch_data.get("id")
        if batch_id is None:
            raise ValueError("batch mirror payload has no id")
        payload = dict(batch_data)
        payload["batch_id"] = int(batch_id)
        payload["synced_at"] = datetime.now(timezone.utc)
        client.collection("myco_batches").document(str(batch_id)).set(payload, merge=True, timeout=5)

    def _delete_batch(self, batch_id: int) -> None:
        client = self._get_client()
        client.collection("myco_batches").document(str(batch_id)).delete(timeout=5)

    async def _run(self) -> None:
        assert self._queue is not None
        while True:
            item = await self._queue.get()
            try:
                for attempt in range(3):
                    try:
                        kind = item.get("kind")
                        if kind == "telemetry":
                            await asyncio.to_thread(self._write_reading, item["data"])
                        elif kind == "batch":
                            await asyncio.to_thread(self._write_batch, item["data"])
                        elif kind == "batch_delete":
                            await asyncio.to_thread(self._delete_batch, item["batch_id"])
                        else:
                            raise ValueError("unknown Firestore mirror item")
                        with self._lock:
                            self._state.update({
                                "connected": True,
                                "checking": False,
                                "last_success_at": datetime.now(timezone.utc).isoformat(),
                                "last_error": None,
                            })
                        break
                    except Exception as exc:  # Firestore must never block local control.
                        error_name = type(exc).__name__
                        with self._lock:
                            self._state.update({"connected": False, "checking": False, "last_error": error_name})
                        if attempt == 2:
                            log.warning("Firestore telemetry write failed (%s)", error_name)
                        else:
                            await asyncio.sleep(0.5 * (attempt + 1))
            finally:
                self._queue.task_done()

    async def check_connection(self) -> None:
        status = self.status()
        if not status["configured"]:
            return
        with self._lock:
            self._state["checking"] = True
        try:
            await asyncio.to_thread(self._ping)
            with self._lock:
                self._state.update({"connected": True, "checking": False, "last_error": None})
        except Exception as exc:
            error_name = type(exc).__name__
            with self._lock:
                self._state.update({"connected": False, "checking": False, "last_error": error_name})
            log.warning("Firestore health check failed (%s)", error_name)


firestore_telemetry = FirestoreTelemetryMirror()

# Hardware reference & integration

The firmware pin map follows the uploaded `MYCO_AI_Practice.ino` practice
sketch. Only the hardware listed here is assumed to exist; the app does not
expect CO₂, light or camera sensors.

## Bill of materials and pin map

| Component | GPIO / connection | Software behavior and limits |
|---|---|---|
| ESP32 dev board | Wi-Fi | HTTP client to the MYCO AI server; timestamp is null until NTP synchronizes |
| DHT11 | GPIO 4 | Temperature and relative humidity; rated 0–50 °C and around 20–90 % RH, with limited accuracy. Treat readings over ~90 % RH as approximate. |
| Analog moisture probe | AO → GPIO 34 | Raw ADC count, 0–4095; AO must not exceed 3.3 V. Value is uncalibrated, not a moisture percentage. |
| Humidifier driver | GPIO 18 | Active-high assumed; verify driver polarity and whether its button input needs a pulse. Never power the humidifier from an ESP32 pin. |
| L293D channel B / fan | ENB GPIO 25, IN3 GPIO 26, IN4 GPIO 27 | Fixed forward direction and on/off enable. Check fan startup/stall current and driver thermal limits; use a suitably rated MOSFET/driver if needed. |
| Isolated heater relay | GPIO 19 | Added output for high-watt bulb control. Relay must be correctly rated and enclosed, with fuse and independent thermal cutoff. Firmware applies a 32 °C cutoff, 30-minute maximum run, 5-minute cooldown, invalid-sensor lockout and backend watchdog. |

Use a suitable supply for each load. Do not wire mains voltage on a breadboard
or connect a bulb, fan or humidifier directly to an ESP32 GPIO. Confirm relay
polarity and add hardware pull-downs so outputs stay off during reset. The
L293D driver and the sensor may not match every board revision; verify the
actual module labels before powering it.

## Integration steps

1. In **Device Management → Add device**, create a hardware device with
   transport **HTTP** and copy its one-time token.
2. Copy `firmware/esp32/myco_esp32/config.example.h` to `config.h`. Set your
   Wi-Fi credentials, device ID/token and `MYCO_API_URL` to the computer's LAN
   address, for example `http://192.168.1.20:8000` (not `localhost`).
3. Start the backend listening on the LAN, for example:
   `uvicorn app.main:app --host 0.0.0.0 --port 8000`. Keep the API on a trusted
   local network; do not expose it publicly over plain HTTP.
4. Flash the sketch with Arduino IDE and open Serial Monitor at 115200 baud.
   Confirm the device appears **ONLINE** and Monitoring shows hardware readings.
5. Keep mode **Monitor** while wiring. Then test manual commands with safe,
   low-voltage loads. The firmware acknowledgement confirms its GPIO output
   level; it cannot confirm physical relay contacts or that a load operated.
6. Create/assign an active batch with the mushroom profile and confirmed growth
   stage. Switch the chamber to **Automatic** after verifying the profile
   ranges and the hardware. The server's control trace explains each command.

Never commit `config.h` or put its device token in frontend code. The service
account JSON for Firebase is a separate server-side secret and is not needed by
this HTTP device transport.

## Safety and behavior

* The backend selects stage targets from the active batch profile and sends
  deterministic commands; chat/AI recommendations cannot operate relays.
* The ESP32 starts outputs OFF, reports every 10 seconds, and polls commands
  every 5 seconds. It always applies local heater interlocks. If the server or
  Wi-Fi is unreachable, it does not autonomously maintain the selected species
  targets; its watchdog turns the heater and humidifier off after 180 seconds
  without a successful authenticated poll. Repeated DHT11 failures also turn
  the humidifier off.
* A DHT11 is not reliable for continuous high-humidity cultivation. Use a
  better-rated sensor before unattended operation at 90–95 % RH. Readings from
  one sensor location cannot reveal chamber gradients.
* The fan can approach ambient temperature but cannot cool below it. Without a
  CO₂ sensor, fresh-air exchange is scheduled from the species/stage profile.
* Growth stages are confirmed by the grower; elapsed time does not establish
  biological progress. No camera means the app cannot infer colonization or
  harvest readiness from appearance.

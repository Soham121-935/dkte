#pragma once

// Copy this file to config.h. Never commit config.h or share your device token.
#define WIFI_SSID "your-wifi-name"
#define WIFI_PASS "your-wifi-password"

// Use the computer's LAN IPv4 address, not localhost/127.0.0.1.
// Example: http://192.168.1.20:8000
#define MYCO_API_URL "http://192.168.1.20:8000"

// Create a hardware device in MYCO AI Device Management, then paste its token.
#define DEVICE_ID "myco-esp32-01"
#define DEVICE_TOKEN "mycodev_replace_with_device_token"
#define FIRMWARE_VERSION "esp32-myco-http-1.1.0"

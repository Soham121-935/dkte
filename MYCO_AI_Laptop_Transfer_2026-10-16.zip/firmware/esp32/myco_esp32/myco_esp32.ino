/*
 * MYCO AI – ESP32 chamber controller (HTTP transport, schema v1)
 *
 * Connects to the MYCO AI FastAPI server over the local network.  The server
 * owns the selected mushroom/stage profile and decides automatic actions;
 * this firmware reads sensors, executes authenticated commands, reports
 * states, and applies safety interlocks even while offline.
 *
 * Practice-code pin mapping retained:
 *   DHT11 data       GPIO 4
 *   substrate AO    GPIO 34 (input only, 0–3.3 V maximum)
 *   humidifier FET  GPIO 18 (active high, verify your driver)
 *   fan / L293D B   ENB 25, IN3 26, IN4 27
 * Added heater output: GPIO 19 to a suitably rated isolated relay module.
 *
 * Do not connect a mains bulb or motor directly to an ESP32 pin. Install a
 * correctly rated, enclosed relay/driver, fuse and independent thermal cutoff.
 * Software interlocks are a second layer only. Test first with low-voltage
 * loads and verify relay polarity before connecting the heater.
 *
 * Libraries: ESP32 Arduino core, ArduinoJson 6/7, Adafruit DHT sensor library,
 * Adafruit Unified Sensor. Copy config.example.h to config.h and configure it.
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <time.h>
#include "config.h"

#if ARDUINOJSON_VERSION_MAJOR >= 7
  #define MYCO_JSON_DOCUMENT(name, capacity) JsonDocument name
#else
  #define MYCO_JSON_DOCUMENT(name, capacity) DynamicJsonDocument name(capacity)
#endif

// ----------------------------- hardware
static constexpr uint8_t PIN_DHT = 4;
static constexpr uint8_t PIN_MOISTURE = 34;
static constexpr uint8_t PIN_HUMIDIFIER = 18;
static constexpr uint8_t PIN_FAN_EN = 25;
static constexpr uint8_t PIN_FAN_IN1 = 26;
static constexpr uint8_t PIN_FAN_IN2 = 27;
static constexpr uint8_t PIN_HEATER = 19;
static constexpr uint8_t DHT_TYPE = DHT11;

// Change these only after confirming the actual driver/relay board polarity.
static constexpr uint8_t HUMIDIFIER_ON = HIGH;
static constexpr uint8_t HUMIDIFIER_OFF = LOW;
static constexpr uint8_t HEATER_ON = HIGH;
static constexpr uint8_t HEATER_OFF = LOW;

// ----------------------------- local safety and intervals
static constexpr float HEATER_CUTOFF_C = 32.0f;
static constexpr uint32_t HEATER_MAX_RUNTIME_MS = 30UL * 60UL * 1000UL;
static constexpr uint32_t HEATER_COOLDOWN_MS = 5UL * 60UL * 1000UL;
static constexpr uint32_t COMMAND_WATCHDOG_MS = 180UL * 1000UL;
static constexpr uint8_t MAX_DHT_FAILURES = 3;
static constexpr uint32_t SENSOR_INTERVAL_MS = 10UL * 1000UL;
static constexpr uint32_t COMMAND_POLL_MS = 5UL * 1000UL;
static constexpr uint32_t WIFI_RETRY_MS = 5UL * 1000UL;
static constexpr uint32_t HTTP_TIMEOUT_MS = 3500;

DHT dht(PIN_DHT, DHT_TYPE);
struct Actuators { bool fan = false; bool heater = false; bool humidifier = false; } actuators;

float temperatureC = NAN;
float humidityPercent = NAN;
uint8_t dhtFailures = 0;
uint32_t heaterOnSince = 0;
uint32_t heaterCooldownStarted = 0;
uint32_t lastBackendContact = 0;
uint32_t lastSensorRead = 0;
uint32_t lastCommandPoll = 0;
uint32_t lastWifiAttempt = 0;
String lastSafetyReason;

String isoTimestamp() {
  const time_t now = time(nullptr);
  if (now < 1700000000) return String();
  struct tm utc;
  gmtime_r(&now, &utc);
  char value[25];
  strftime(value, sizeof(value), "%Y-%m-%dT%H:%M:%SZ", &utc);
  return String(value);
}

String newId() {
  char value[25];
  snprintf(value, sizeof(value), "%08lx%08lx%08lx", (unsigned long)esp_random(),
           (unsigned long)esp_random(), (unsigned long)esp_random());
  return String(value);
}

void writeFan(bool on) {
  // L293D channel B direction is fixed forward; ENB switches the fan.
  digitalWrite(PIN_FAN_IN1, HIGH);
  digitalWrite(PIN_FAN_IN2, LOW);
  digitalWrite(PIN_FAN_EN, on ? HIGH : LOW);
}

void writeHeater(bool on) {
  digitalWrite(PIN_HEATER, on ? HEATER_ON : HEATER_OFF);
  actuators.heater = on;
  heaterOnSince = on ? millis() : 0;
}

void setActuator(const String &name, bool on) {
  if (name == "fan") {
    writeFan(on);
    actuators.fan = on;
  } else if (name == "heater") {
    writeHeater(on);
  } else if (name == "humidifier") {
    digitalWrite(PIN_HUMIDIFIER, on ? HUMIDIFIER_ON : HUMIDIFIER_OFF);
    actuators.humidifier = on;
  }
}

String heaterLockout() {
  if (isnan(temperatureC) || dhtFailures >= MAX_DHT_FAILURES) return "no_valid_temperature";
  if (temperatureC >= HEATER_CUTOFF_C) return "local_thermal_cutoff";
  if (heaterCooldownStarted && (uint32_t)(millis() - heaterCooldownStarted) < HEATER_COOLDOWN_MS) return "heater_cooldown";
  if (lastBackendContact && (uint32_t)(millis() - lastBackendContact) > COMMAND_WATCHDOG_MS) return "backend_watchdog";
  return String();
}

void enforceSafety() {
  String reason = heaterLockout();
  const bool backendStale = lastBackendContact &&
      (uint32_t)(millis() - lastBackendContact) > COMMAND_WATCHDOG_MS;
  if (actuators.humidifier && (backendStale || dhtFailures >= MAX_DHT_FAILURES)) {
    setActuator("humidifier", false);
    lastSafetyReason = backendStale ? "backend_watchdog" : "no_valid_humidity";
    Serial.printf("[safety] humidifier forced OFF: %s\n", lastSafetyReason.c_str());
  }
  if (actuators.heater && (uint32_t)(millis() - heaterOnSince) >= HEATER_MAX_RUNTIME_MS) {
    heaterCooldownStarted = millis();
    reason = "heater_max_runtime";
  }
  if (actuators.heater && reason.length()) {
    writeHeater(false);
    lastSafetyReason = reason;
    Serial.printf("[safety] heater forced OFF: %s\n", reason.c_str());
  }
}

bool beginRequest(HTTPClient &http, const String &path) {
  const String url = String(MYCO_API_URL) + path;
  if (!http.begin(url)) return false;
  http.setTimeout(HTTP_TIMEOUT_MS);
  http.addHeader("X-Device-Token", DEVICE_TOKEN);
  return true;
}

void readSensors() {
  const float t = dht.readTemperature();
  const float rh = dht.readHumidity();
  if (isnan(t) || isnan(rh)) {
    if (dhtFailures < 255) dhtFailures++;
    if (dhtFailures >= MAX_DHT_FAILURES) {
      temperatureC = NAN;
      humidityPercent = NAN;
    }
    Serial.printf("[sensor] DHT11 read failed (%u/%u)\n", dhtFailures, MAX_DHT_FAILURES);
  } else {
    temperatureC = t;
    humidityPercent = rh;
    dhtFailures = 0;
  }
}

bool postTelemetry() {
  HTTPClient http;
  if (!beginRequest(http, "/api/ingest/telemetry")) return false;
  http.addHeader("Content-Type", "application/json");

  MYCO_JSON_DOCUMENT(doc, 768);
  doc["schema_version"] = 1;
  doc["device_id"] = DEVICE_ID;
  doc["message_id"] = newId();
  const String timestamp = isoTimestamp();
  if (timestamp.length()) doc["timestamp"] = timestamp; else doc["timestamp"] = nullptr;
  doc["uptime_ms"] = millis();
  if (isnan(temperatureC)) doc["temperature_c"] = nullptr; else doc["temperature_c"] = temperatureC;
  if (isnan(humidityPercent)) doc["relative_humidity_percent"] = nullptr; else doc["relative_humidity_percent"] = humidityPercent;
  long moistureTotal = 0;
  for (int i = 0; i < 8; i++) { moistureTotal += analogRead(PIN_MOISTURE); delay(2); }
  doc["substrate_moisture_raw"] = moistureTotal / 8;
  JsonArray sensorErrors = doc["sensor_errors"].to<JsonArray>();
  if (dhtFailures) sensorErrors.add("dht11");
  doc["fan_state"] = actuators.fan;
  doc["heater_state"] = actuators.heater;
  doc["humidifier_state"] = actuators.humidifier;
  doc["firmware_version"] = FIRMWARE_VERSION;
  doc["source"] = "hardware";
  doc["rssi_dbm"] = WiFi.RSSI();
  String body;
  serializeJson(doc, body);
  const int code = http.POST(body);
  const String reply = code > 0 ? http.getString() : String();
  http.end();
  if (code >= 200 && code < 300) {
    Serial.printf("[api] telemetry accepted (%d)\n", code);
    return true;
  }
  Serial.printf("[api] telemetry failed (%d) %s\n", code, reply.c_str());
  return false;
}

time_t parseUtcTimestamp(const char *value) {
  if (!value || strlen(value) < 19) return 0;
  struct tm parsed = {};
  if (!strptime(value, "%Y-%m-%dT%H:%M:%S", &parsed)) return 0;
  return mktime(&parsed); // TZ is explicitly UTC in setup().
}

void acknowledgeCommand(const String &commandId, const String &actuator, bool requested, const char *status, const char *error) {
  HTTPClient http;
  if (!beginRequest(http, "/api/ingest/command-status")) return;
  http.addHeader("Content-Type", "application/json");
  MYCO_JSON_DOCUMENT(doc, 512);
  doc["schema_version"] = 1;
  doc["device_id"] = DEVICE_ID;
  doc["command_id"] = commandId;
  doc["message_id"] = newId();
  const String timestamp = isoTimestamp();
  if (timestamp.length()) doc["timestamp"] = timestamp; else doc["timestamp"] = nullptr;
  doc["actuator"] = actuator;
  doc["requested_state"] = requested;
  const bool result = actuator == "fan" ? actuators.fan : actuator == "heater" ? actuators.heater : actuators.humidifier;
  doc["result_state"] = result;
  doc["status"] = status;
  if (error) doc["error"] = error; else doc["error"] = nullptr;
  String body;
  serializeJson(doc, body);
  const int code = http.POST(body);
  if (code < 200 || code >= 300) Serial.printf("[api] command acknowledgement failed (%d)\n", code);
  http.end();
}

void handleCommand(JsonObject command) {
  String errorStorage;
  const String commandId = command["command_id"] | "";
  const String commandDevice = command["device_id"] | "";
  const String actuator = command["actuator"] | "";
  const bool requested = command["state"] | false;
  const char *error = nullptr;
  const char *status = "applied";

  if (!commandId.length() || commandDevice != DEVICE_ID) error = "invalid_command";
  else if (actuator != "fan" && actuator != "heater" && actuator != "humidifier") error = "unknown_actuator";
  else {
    const int ttl = constrain((int)(command["ttl_seconds"] | 60), 5, 600);
    const time_t issued = parseUtcTimestamp(command["timestamp"] | "");
    const time_t now = time(nullptr);
    if (issued && now > 1700000000 && difftime(now, issued) > ttl) error = "command_expired";
    else if (actuator == "heater" && requested) {
      errorStorage = heaterLockout();
      if (errorStorage.length()) error = errorStorage.c_str();
    }
  }

  if (error) status = "rejected";
  else {
    setActuator(actuator, requested);
    enforceSafety();
    const bool actual = actuator == "fan" ? actuators.fan : actuator == "heater" ? actuators.heater : actuators.humidifier;
    if (actual != requested) { status = "rejected"; error = "local_safety_interlock"; }
  }
  Serial.printf("[command] %s %s -> %s (%s)\n", actuator.c_str(), requested ? "ON" : "OFF", status, commandId.c_str());
  acknowledgeCommand(commandId, actuator, requested, status, error);
}

void pollCommands() {
  HTTPClient http;
  if (!beginRequest(http, "/api/ingest/commands")) return;
  const int code = http.GET();
  const String body = code > 0 ? http.getString() : String();
  http.end();
  if (code < 200 || code >= 300) {
    Serial.printf("[api] command poll failed (%d)\n", code);
    return;
  }
  lastBackendContact = millis(); // successful authenticated poll is the backend watchdog heartbeat
  MYCO_JSON_DOCUMENT(doc, 4096);
  const DeserializationError err = deserializeJson(doc, body);
  if (err) { Serial.printf("[api] invalid command response: %s\n", err.c_str()); return; }
  JsonArray commands = doc["commands"].as<JsonArray>();
  for (JsonObject command : commands) handleCommand(command);
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED || (uint32_t)(millis() - lastWifiAttempt) < WIFI_RETRY_MS) return;
  lastWifiAttempt = millis();
  Serial.printf("[wifi] connecting to %s\n", WIFI_SSID);
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASS);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_FAN_EN, OUTPUT);
  pinMode(PIN_FAN_IN1, OUTPUT);
  pinMode(PIN_FAN_IN2, OUTPUT);
  pinMode(PIN_HEATER, OUTPUT);
  pinMode(PIN_HUMIDIFIER, OUTPUT);
  pinMode(PIN_MOISTURE, INPUT);
  digitalWrite(PIN_FAN_EN, LOW);
  digitalWrite(PIN_HEATER, HEATER_OFF);
  digitalWrite(PIN_HUMIDIFIER, HUMIDIFIER_OFF);
  writeFan(false);
  analogReadResolution(12);
  dht.begin();

  setenv("TZ", "UTC0", 1);
  tzset();
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  connectWiFi();
  Serial.println("MYCO AI ESP32 HTTP controller ready; all relays start OFF.");
}

void loop() {
  connectWiFi();
  const uint32_t now = millis();

  if ((uint32_t)(now - lastSensorRead) >= SENSOR_INTERVAL_MS) {
    lastSensorRead = now;
    readSensors();
    enforceSafety();
    if (WiFi.status() == WL_CONNECTED) postTelemetry();
  }
  if ((uint32_t)(now - lastCommandPoll) >= COMMAND_POLL_MS) {
    lastCommandPoll = now;
    if (WiFi.status() == WL_CONNECTED) pollCommands();
  }
  enforceSafety(); // remains active if Wi-Fi/API stops responding
  delay(20);
}

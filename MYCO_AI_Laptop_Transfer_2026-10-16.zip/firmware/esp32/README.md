# MYCO AI ESP32 firmware

`myco_esp32/myco_esp32.ino` is the reference HTTP firmware for the uploaded
practice-code hardware. It reports DHT11 and analog moisture readings to the
MYCO AI backend and polls the backend for authenticated actuator commands.
It does not need a separate MQTT broker.

## Pin map

| Component | ESP32 GPIO | Connection |
|---|---:|---|
| DHT11 data | 4 | DHT11 data pin; use the module's pull-up or a 10 kΩ pull-up to 3.3 V |
| Moisture sensor AO | 34 | Analog input only; AO must stay at or below 3.3 V |
| Humidifier driver input | 18 | Active-high assumed; verify the actual driver and whether it expects a pulse |
| Fan driver ENB | 25 | L293D channel B enable |
| Fan driver IN3 | 26 | L293D channel B direction |
| Fan driver IN4 | 27 | L293D channel B direction |
| Heater relay input | 19 | Added output for an isolated, suitably rated relay module |

The motor driver is retained from `MYCO_AI_Practice.ino`. Verify its voltage,
thermal and stall-current limits against the fan. Use a rated MOSFET/driver if
the fan exceeds them. Do not power a fan, humidifier or bulb from an ESP32 pin.
For a mains bulb, use an enclosed relay rated for the load, proper fusing and an
independent thermal fuse/cutoff. Confirm active-high/active-low polarity before
connecting loads; add hardware pull-downs so outputs remain off during reset.

## Configure and flash

1. Install the ESP32 Arduino board package, **ArduinoJson 6 or 7**, Adafruit
   **DHT sensor library**, and **Adafruit Unified Sensor**.
2. Copy `myco_esp32/config.example.h` to `myco_esp32/config.h`.
3. Set Wi-Fi name/password, `MYCO_API_URL`, the registered `DEVICE_ID` and its
   one-time device token. Use the computer's LAN address for `MYCO_API_URL`,
   such as `http://192.168.1.20:8000`; `localhost` will point to the ESP32.
4. Start the FastAPI server bound to the LAN, for example:
   `uvicorn app.main:app --host 0.0.0.0 --port 8000`.
5. Register a hardware device with transport **HTTP** in MYCO AI Device
   Management. Copy its token into `config.h`, select the matching device ID,
   then flash the sketch and open Serial Monitor at 115200 baud.
6. Keep the device in **monitor** mode while you verify telemetry and wiring.
   Test manual low-voltage loads first. Only enable Automatic after confirming
   your selected species profile and stage targets.

Never commit `config.h`, place the device token in frontend code, or expose the
HTTP API directly to the public internet. For remote installations, use an
authenticated TLS endpoint instead of plain HTTP on a trusted local network.

## Control and safety

The active batch linked to the device supplies the selected mushroom and
confirmed growth-stage targets. In **Automatic** mode, the backend's
deterministic controller compares those targets with telemetry and sends relay
commands. MYCO AI chat recommendations cannot operate relays. A stage must be
confirmed by the grower; time alone does not change it.

The firmware starts all outputs OFF, reports telemetry every 10 seconds and
polls commands every 5 seconds. Local interlocks always run: the heater is
rejected/turned off without valid temperature, at or above 32 °C, after 30
minutes continuously on (then a 5-minute cooldown), or after 180 seconds
without a successful authenticated backend poll. The humidifier is also forced
off after repeated DHT failures or a backend-watchdog timeout. It does not autonomously
maintain species targets while the API is unreachable. A reported command
acknowledgement verifies the ESP32 output state, not a physical relay contact
or whether a heater/fan/humidifier actually moved air or water.

The DHT11 is not accurate enough for precise cultivation, especially near its
upper humidity rating. Treat readings above about 90 % RH as approximate; use a
better-rated sensor for sustained high-humidity operation. The analog moisture
value is raw and uncalibrated, not a percentage.

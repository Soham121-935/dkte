import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from '@/App';
import { FIXTURES, WebSocketStub, installFetchMock, json, renderApp, type FetchMock } from '@/test/helpers';

describe('batch cultivation workflows', () => {
  let fetchMock: FetchMock;
  beforeEach(() => {
    WebSocketStub.instances.length = 0;
    vi.stubGlobal('WebSocket', WebSocketStub);
    fetchMock = installFetchMock([
      ['POST', /^\/api\/batches$/, ({ body }) => json(201, { ...FIXTURES.batches[0], id: 8, code: 'B-2026-008', name: (body as { name: string }).name, status: 'planned' })],
      ['POST', /^\/api\/batches\/\d+\/observations$/, ({ body }) => json(201, { ...FIXTURES.observations[0], note: (body as { note: string }).note, kind: (body as { kind: string }).kind })],
    ]);
  });
  afterEach(() => { fetchMock.restore(); vi.unstubAllGlobals(); });

  it('creates a batch with a validated name and species', async () => {
    const user = userEvent.setup();
    renderApp(<App />, { route: '/batches' });
    await screen.findByRole('heading', { level: 1, name: 'Batches' });
    await user.click(screen.getByRole('button', { name: 'New batch' }));
    const dialog = await screen.findByRole('dialog', { name: 'Start a cultivation batch' });
    await user.type(within(dialog).getByPlaceholderText('e.g. North shelf — October'), 'October oyster run');
    await user.click(within(dialog).getByRole('button', { name: 'Create batch' }));
    await waitFor(() => expect(fetchMock.calls.some((c) => c.method === 'POST' && c.url === '/api/batches')).toBe(true));
    expect(fetchMock.calls.find((c) => c.method === 'POST' && c.url === '/api/batches')?.body).toMatchObject({ name: 'October oyster run', species: 'Oyster mushroom', status: 'planned' });
    expect(await screen.findByText('Batch created')).toBeInTheDocument();
  });

  it('records a dated observation against the selected batch', async () => {
    const user = userEvent.setup();
    renderApp(<App />, { route: '/batches' });
    await screen.findByRole('heading', { level: 1, name: 'Batches' });
    await user.click(await screen.findByText(FIXTURES.batches[0].name));
    await screen.findByText('Cultivation lifecycle');
    await user.click(screen.getAllByRole('button', { name: 'Record observation' })[0]);
    const dialog = await screen.findByRole('dialog', { name: 'Record batch observation' });
    await user.type(within(dialog).getByPlaceholderText('Describe the visible observation or record'), 'Pins first appeared on the upper shelf.');
    expect(within(dialog).getByPlaceholderText('Describe the visible observation or record')).toHaveValue('Pins first appeared on the upper shelf.');
    await user.click(within(dialog).getByRole('button', { name: 'Save record' }));
    await waitFor(() => expect(fetchMock.calls.some((c) => c.method === 'POST' && /^\/api\/batches\/\d+\/observations$/.test(c.url))).toBe(true));
    expect(fetchMock.calls.find((c) => c.method === 'POST' && /\/observations$/.test(c.url))?.body).toMatchObject({ kind: 'note', note: 'Pins first appeared on the upper shelf.' });
  });
});

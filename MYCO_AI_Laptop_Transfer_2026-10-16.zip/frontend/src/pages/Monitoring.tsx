import { useState } from 'react';
import { Activity, Beaker, CircleAlert, RefreshCw, Wifi, WifiOff } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { endpoints, type RangeKey } from '@/api/endpoints';
import { MetricChart, ActuatorChart, gapsFromRows, toChartRows } from '@/components/charts';
import { ActuatorChip, ConnectionBadge, SourceTag } from '@/components/domain';
import { Badge, Button, Card, EmptyState, ErrorState, Loading } from '@/components/ui';
import { qk, useAlerts, useBatches, useControl, useLatest, useSeries, useSystemStatus } from '@/lib/queries';
import { fmtAgo, fmtNumber } from '@/lib/format';
import { useDevice } from '@/providers/DeviceProvider';
import { useToast } from '@/providers/ToastProvider';

const ranges: { key: RangeKey; label: string }[] = [{ key: '1h', label: '1 hour' }, { key: '24h', label: '24 hours' }, { key: '7d', label: '7 days' }];
function Metric({ label, value, unit, note }: { label: string; value: string; unit: string; note?: string }) {
  return <div className="rounded-md border border-line bg-surface-2 px-3 py-2.5"><p className="label">{label}</p><p className="mt-1 font-mono text-xl font-semibold text-ink">{value}<span className="ml-1 text-xs font-normal text-ink-3">{unit}</span></p>{note && <p className="mt-1 text-[10px] text-ink-3">{note}</p>}</div>;
}

export default function Monitoring() {
  const { device, deviceId } = useDevice();
  const [range, setRange] = useState<RangeKey>('24h');
  const latest = useLatest(deviceId);
  const control = useControl(deviceId);
  const batches = useBatches({ status: 'active' });
  const activeBatch = (batches.data ?? []).find((batch) => batch.device_id === deviceId);
  const series = useSeries(deviceId, { range });
  const alerts = useAlerts({ status: 'active', limit: 10 });
  const systemStatus = useSystemStatus();
  const queryClient = useQueryClient();
  const toast = useToast();
  const simulator = useMutation({
    mutationFn: (start: boolean) => start ? endpoints.simulatorStart() : endpoints.simulatorStop(),
    onSuccess: async (_data, start) => { await queryClient.invalidateQueries({ queryKey: qk.status }); await queryClient.invalidateQueries({ queryKey: qk.latest(deviceId ?? '') }); toast.success(start ? 'Simulator resumed' : 'Simulator paused'); },
    onError: (e) => toast.error('Simulator setting failed', e instanceof Error ? e.message : 'Try again.'),
  });
  const reading = latest.data?.reading;
  const rows = series.data ? toChartRows(series.data.points, series.data.bucket_seconds) : [];
  const gaps = series.data ? gapsFromRows(rows, series.data.bucket_seconds) : [];
  const sim = device?.kind === 'simulated';
  const simEnabled = Boolean(sim && systemStatus.data?.simulator.enabled);
  const targets = latest.data?.targets ?? control.data?.targets ?? activeBatch?.effective_targets ?? null;
  const targetRange = (min: number | null | undefined, max: number | null | undefined, unit: string) => min == null || max == null ? 'Not configured' : `${min}–${max}${unit}`;
  const controlMode = control.data?.mode ?? device?.control_mode ?? 'monitor';
  return <div className="space-y-4">
    <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="label">Growing environment</p><h1 className="mt-1 font-display text-2xl text-ink">Environmental monitoring</h1><p className="mt-1 text-sm text-ink-2">Sensor readings and reported equipment states for the selected chamber.</p></div><div className="flex items-center gap-2">{sim && <Button size="sm" icon={simEnabled ? <Activity className="h-3.5 w-3.5"/> : <RefreshCw className="h-3.5 w-3.5"/>} loading={simulator.isPending} onClick={() => simulator.mutate(!simEnabled)}>{simEnabled ? 'Pause simulator' : 'Resume simulator'}</Button>}<span className="flex items-center gap-1 rounded-full border border-line bg-surface px-2.5 py-1 text-xs text-ink-2">{device?.connection_status === 'online' ? <Wifi className="h-3.5 w-3.5 text-brand"/> : <WifiOff className="h-3.5 w-3.5 text-amber"/>}{device?.connection_status ?? 'No device'}</span></div></div>
    <Card title="Grow profile driving this chamber" subtitle="Species and confirmed growth stage set the target ranges used by Automatic control.">
      {activeBatch?.profile ? <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2"><Badge tone="brand">{activeBatch.species}</Badge><Badge>{activeBatch.current_stage_name ?? 'Stage not confirmed'}</Badge><Badge tone={activeBatch.profile.source === 'reference' ? 'amber' : 'neutral'}>{activeBatch.profile.source === 'reference' ? 'Reference profile' : 'Your profile'}</Badge></div>
          <p className="mt-2 text-sm font-medium text-ink">{activeBatch.name} · {activeBatch.profile.name}</p>
          <p className="mt-1 text-xs text-ink-2">Temperature {targetRange(targets?.temperature_min_c, targets?.temperature_max_c, ' °C')} · Humidity {targetRange(targets?.humidity_min_percent, targets?.humidity_max_percent, '%')}</p>
          {activeBatch.profile.source_notes && <p className="mt-2 max-w-3xl text-xs leading-relaxed text-ink-3">{activeBatch.profile.source_notes}</p>}
        </div>
        <div className="flex shrink-0 flex-col items-start gap-2 sm:items-end"><Badge tone={controlMode === 'auto' ? 'brand' : controlMode === 'manual' ? 'amber' : 'neutral'}>{controlMode === 'auto' ? 'Automatic control' : controlMode === 'manual' ? 'Manual control' : 'Monitoring only'}</Badge><Link to="/batches" className="text-xs font-semibold text-brand underline-offset-2 hover:underline">Change species or batch →</Link></div>
      </div> : <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm font-medium text-ink">No active species profile is linked to this chamber.</p><p className="mt-1 text-xs text-ink-2">Create or edit a batch, choose its mushroom profile and growth stage, then select Automatic control to use those targets.</p></div><Link to="/batches" className="inline-flex min-h-9 shrink-0 items-center justify-center rounded-md bg-brand px-3 text-xs font-semibold text-white hover:brightness-105">Choose a mushroom</Link></div>}
      {controlMode === 'auto' && activeBatch?.profile && <p className="mt-3 border-t border-line pt-3 text-[11px] text-ink-3">The backend compares sensor readings with this stage’s ranges and sends commands to the ESP32. The ESP32 applies local heater safety cutoffs. It does not infer growth stage; confirm stage changes in Overview.</p>}
    </Card>
    <Card title="Firebase cloud sync" subtitle="Hardware readings are mirrored from the backend into Firestore; the service-account key stays server-side.">
      {(() => {
        const firebase = systemStatus.data?.firebase;
        const state = !firebase?.enabled ? 'Not configured' : !firebase.configured ? 'Setup needed' : firebase.connected ? 'Connected' : firebase.checking ? 'Checking connection' : 'Not connected';
        const tone = firebase?.connected ? 'brand' : firebase?.checking ? 'neutral' : 'amber';
        return <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex flex-wrap items-center gap-2"><Badge tone={tone}>{state}</Badge>{firebase?.project_id && <span className="font-mono text-[11px] text-ink-3">{firebase.project_id}</span>}</div><p className="mt-2 text-xs text-ink-2">{firebase?.detail ?? 'Waiting for Firebase status from the backend…'}</p>{firebase?.last_success_at && <p className="mt-1 text-[11px] text-ink-3">Last hardware reading synced {fmtAgo(firebase.last_success_at)}{firebase.pending_writes ? ` · ${firebase.pending_writes} queued` : ''}</p>}</div></div>;
      })()}
    </Card>
    <Card title={device?.name ?? 'Selected chamber'} subtitle={device ? `${device.id} · ${device.transport}` : 'Select a chamber in Connections'} actions={<ConnectionBadge status={device?.connection_status ?? 'unknown'} lastSeen={device?.last_telemetry_at ?? null}/> }>
      {latest.isLoading ? <Loading label="Reading the latest sensor report…"/> : latest.error ? <ErrorState error={latest.error} onRetry={() => latest.refetch()}/> : reading ? <><div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4"><Metric label="Temperature" value={fmtNumber(reading.temperature_c, 1)} unit="°C"/><Metric label="Relative humidity" value={fmtNumber(reading.relative_humidity_percent, 0)} unit="%"/><Metric label="Substrate sensor" value={fmtNumber(reading.substrate_moisture_raw, 0)} unit="raw ADC" note="Uncalibrated sensor value; not a moisture percentage."/><Metric label="Last report" value={fmtAgo(reading.measured_at)} unit="ago" note={fmtAgo(reading.received_at) !== fmtAgo(reading.measured_at) ? 'Device timestamp; server receipt can differ.' : undefined}/></div><div className="mt-3 flex flex-wrap items-center gap-2"><SourceTag source={reading.source}/><Badge tone={reading.quality?.temperature_c === 'ok' && reading.quality?.relative_humidity_percent === 'ok' ? 'brand' : 'amber'}>Sensor quality: {reading.quality?.temperature_c ?? 'unknown'}</Badge>{latest.data?.targets && <span className="text-[11px] text-ink-3">Target ranges: {latest.data.targets.temperature_min_c}–{latest.data.targets.temperature_max_c} °C · {latest.data.targets.humidity_min_percent}–{latest.data.targets.humidity_max_percent} % ({latest.data.targets.source_label ?? latest.data.targets.source})</span>}</div></> : <EmptyState title="No readings received" description="The chamber has not reported telemetry yet. The app will keep showing this state until readings arrive."/>}
    </Card>
    <Card title="Reading history" subtitle={series.data ? `${series.data.n_readings} recorded samples · ${series.data.sources.join(', ') || 'no source'}` : 'Select a range'} actions={<div className="flex rounded-full bg-surface-2 p-1" role="group" aria-label="History time range">{ranges.map((item) => <button key={item.key} type="button" aria-pressed={range === item.key} onClick={() => setRange(item.key)} className={`min-h-8 rounded-full px-3 text-xs font-medium ${range === item.key ? 'bg-surface text-ink shadow-sm' : 'text-ink-2'}`}>{item.label}</button>)}</div>}>
      {series.isLoading ? <Loading label="Loading history…"/> : series.error ? <ErrorState error={series.error} onRetry={() => series.refetch()}/> : series.data?.points.length ? <div className="grid gap-5 lg:grid-cols-2"><div><p className="mb-1 text-xs font-medium text-ink-2">Temperature · °C</p><MetricChart rows={rows} metric="temperature_c" targets={series.data.targets} gaps={gaps}/></div><div><p className="mb-1 text-xs font-medium text-ink-2">Relative humidity · %</p><MetricChart rows={rows} metric="relative_humidity_percent" targets={series.data.targets} gaps={gaps}/></div><div><p className="mb-1 text-xs font-medium text-ink-2">Substrate sensor · raw ADC counts</p><MetricChart rows={rows} metric="substrate_moisture_raw" targets={series.data.targets} gaps={gaps}/></div><div><p className="mb-1 text-xs font-medium text-ink-2">Reported actuator states</p><ActuatorChart rows={rows}/></div></div> : <EmptyState title="No history in this range" description="History will appear after the selected chamber reports sensor readings." icon={<Beaker className="h-6 w-6"/>}/>}
    </Card>
    <div className="grid gap-4 lg:grid-cols-2"><Card title="Equipment state" subtitle="Reported or confirmed physical state; a requested command is shown separately."><div className="grid gap-2 sm:grid-cols-3">{(['humidifier','fan','heater'] as const).map((a) => <ActuatorChip key={a} actuator={a} entry={device?.actuator_state[a]} reported={reading?.[`${a}_state` as 'fan_state' | 'heater_state' | 'humidifier_state'] ?? null}/>)}</div><p className="mt-3 text-[11px] text-ink-3">Fan circulation does not guarantee fresh-air exchange. AI guidance cannot operate relays; local controller safety logic remains authoritative.</p></Card>
      <Card title="Active environmental alerts" subtitle="Configured thresholds and device reporting health." padded={false}>{alerts.isLoading ? <Loading className="px-4"/> : alerts.error ? <ErrorState error={alerts.error} onRetry={() => alerts.refetch()}/> : alerts.data?.length ? <ul className="divide-y divide-line">{alerts.data.slice(0, 5).map((alert) => <li key={alert.id} className="flex items-start gap-2 px-4 py-3"><CircleAlert className={`mt-0.5 h-4 w-4 shrink-0 ${alert.severity === 'critical' ? 'text-danger' : 'text-amber'}`}/><div><p className="text-sm font-medium text-ink">{alert.title}</p><p className="text-xs text-ink-2">{alert.message}</p><p className="mt-1 text-[10px] text-ink-3">{fmtAgo(alert.opened_at)}</p></div></li>)}</ul> : <EmptyState title="No active alerts" description="The environment is not currently reporting a configured threshold deviation."/>}</Card></div>
  </div>;
}

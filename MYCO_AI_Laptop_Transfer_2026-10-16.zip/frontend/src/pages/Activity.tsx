import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Bell, CheckCheck, Clock3, Leaf } from 'lucide-react';
import { endpoints } from '@/api/endpoints';
import type { Alert, SystemEvent } from '@/api/types';
import { Badge, Button, Card, EmptyState, ErrorState, Loading, severityTone } from '@/components/ui';
import { fmtAgo } from '@/lib/format';
import { useAlerts } from '@/lib/queries';
import { useToast } from '@/providers/ToastProvider';

export default function Activity() {
  const queryClient = useQueryClient();
  const toast = useToast();
  const alerts = useAlerts({ limit: 100 });
  const events = useQuery({ queryKey: ['events', { limit: 100 }], queryFn: () => endpoints.systemEvents({ limit: 100 }) });
  const acknowledge = useMutation({ mutationFn: (id: number) => endpoints.acknowledgeAlert(id), onSuccess: async () => { await Promise.all([queryClient.invalidateQueries({ queryKey: ['alerts'] }), queryClient.invalidateQueries({ queryKey: ['system', 'status'] })]); toast.success('Alert acknowledged'); }, onError: (e) => toast.error('Could not acknowledge alert', e instanceof Error ? e.message : 'Try again.') });
  const orderedEvents = [...(events.data ?? [])].sort((a, b) => b.created_at.localeCompare(a.created_at));
  return <div className="space-y-4">
    <div><p className="label">Alerts & records</p><h1 className="mt-1 font-display text-2xl text-ink">Activity</h1><p className="mt-1 text-sm text-ink-2">Environmental alerts and system events, with acknowledgement history.</p></div>
    <Card title="Environmental alerts" subtitle="Alerts are raised from configured limits, sensor quality, and device connectivity." padded={false}>{alerts.isLoading ? <Loading label="Loading alerts…" className="px-4"/> : alerts.error ? <ErrorState error={alerts.error} onRetry={() => alerts.refetch()}/> : alerts.data?.length ? <ul className="divide-y divide-line">{alerts.data.map((a: Alert) => <li key={a.id} className="flex flex-wrap items-start gap-3 px-4 py-3"><Bell className={`mt-0.5 h-4 w-4 shrink-0 ${a.severity === 'critical' ? 'text-danger' : 'text-amber'}`}/><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-ink">{a.title}</p><Badge tone={severityTone(a.severity)}>{a.severity}</Badge><Badge tone={a.status === 'active' ? 'amber' : a.status === 'resolved' ? 'teal' : 'neutral'}>{a.status}</Badge></div><p className="mt-1 text-xs text-ink-2">{a.message}</p><p className="mt-1 text-[10px] text-ink-3">{a.device_id ?? 'System'} · {fmtAgo(a.opened_at)} · {a.occurrence_count > 1 ? `${a.occurrence_count} occurrences` : '1 occurrence'}{a.acknowledged_by ? ` · acknowledged by ${a.acknowledged_by}` : ''}</p></div>{a.status === 'active' && <Button size="sm" icon={<CheckCheck className="h-3.5 w-3.5"/>} loading={acknowledge.isPending && acknowledge.variables === a.id} onClick={() => acknowledge.mutate(a.id)}>Acknowledge</Button>}</li>)}</ul> : <EmptyState title="No alerts recorded" description="Environmental deviations and sensor faults will appear here when present."/>}</Card>
    <Card title="Recent system and cultivation activity" subtitle="Device connection changes, batch transitions, observations, and recorded operations." padded={false}>{events.isLoading ? <Loading className="px-4"/> : events.error ? <ErrorState error={events.error} onRetry={() => events.refetch()}/> : orderedEvents.length ? <ol className="divide-y divide-line">{orderedEvents.map((event: SystemEvent) => <li key={event.id} className="flex gap-3 px-4 py-3"><div className="mt-0.5 rounded-full bg-surface-2 p-1.5 text-brand">{event.category.toLowerCase().includes('batch') ? <Leaf className="h-3.5 w-3.5"/> : <Clock3 className="h-3.5 w-3.5"/>}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><Badge>{event.category}</Badge>{event.level !== 'info' && <Badge tone={event.level === 'error' ? 'danger' : 'amber'}>{event.level}</Badge>}</div><p className="mt-1 text-sm text-ink-2">{event.message}</p><p className="mt-1 text-[10px] text-ink-3">{event.device_id ?? 'System'} · {fmtAgo(event.created_at)}</p></div></li>)}</ol> : <EmptyState title="No activity yet" description="Stage confirmations, observations, and device events will be recorded here."/>}</Card>
  </div>;
}

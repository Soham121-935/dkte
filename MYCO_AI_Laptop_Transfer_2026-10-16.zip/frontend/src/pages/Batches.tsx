import { useMemo, useState } from 'react';
import { Check, ChevronRight, Leaf, Plus, Sprout } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { endpoints } from '@/api/endpoints';
import type { Batch, Observation } from '@/api/types';
import { Button, Badge, Card, EmptyState, ErrorState, Field, Input, Loading, Modal, Select, Textarea } from '@/components/ui';
import { useBatches, useProfiles } from '@/lib/queries';
import { fmtDateTime } from '@/lib/format';
import { useToast } from '@/providers/ToastProvider';
import { useDevice } from '@/providers/DeviceProvider';

type BatchForm = { name: string; species: string; strain: string; substrate_type: string; spawn_details: string; inoculation_date: string; profile_id: string; notes: string; status: string; link_device: boolean };
const blankForm: BatchForm = { name: '', species: 'Oyster mushroom', strain: '', substrate_type: 'Pasteurized straw', spawn_details: '', inoculation_date: '', profile_id: '', notes: '', status: 'planned', link_device: false };
const localDateTimeValue = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };

function BatchEditor({ batch, onClose }: { batch?: Batch; onClose: () => void }) {
  const { data: profiles = [] } = useProfiles();
  const { deviceId } = useDevice();
  const queryClient = useQueryClient();
  const toast = useToast();
  const [form, setForm] = useState<BatchForm>(batch ? {
    name: batch.name, species: batch.species, strain: batch.strain ?? '', substrate_type: batch.substrate_type ?? '',
    inoculation_date: batch.inoculation_date?.slice(0, 10) ?? '', profile_id: batch.profile_id ? String(batch.profile_id) : '', notes: batch.notes ?? '',
    spawn_details: batch.spawn_details ?? '', status: batch.status, link_device: Boolean(batch.device_id),
  } : blankForm);
  const [error, setError] = useState('');
  const save = useMutation({
    mutationFn: () => batch
      ? endpoints.updateBatch(batch.id, { name: form.name.trim(), species: form.species.trim(), strain: form.strain || null, substrate_type: form.substrate_type || null, spawn_details: form.spawn_details || null, inoculation_date: form.inoculation_date ? `${form.inoculation_date}T00:00:00Z` : null, profile_id: form.profile_id ? Number(form.profile_id) : null, status: form.status, notes: form.notes || null })
      : endpoints.createBatch({ name: form.name.trim(), species: form.species.trim(), strain: form.strain || null, substrate_type: form.substrate_type || null, spawn_details: form.spawn_details || null, inoculation_date: form.inoculation_date ? `${form.inoculation_date}T00:00:00Z` : null, profile_id: form.profile_id ? Number(form.profile_id) : null, device_id: form.link_device ? deviceId : null, status: form.status, notes: form.notes || null }),
    onSuccess: async () => { await queryClient.invalidateQueries({ queryKey: ['batches'] }); toast.success(batch ? 'Batch details saved' : 'Batch created'); onClose(); },
    onError: (e) => setError(e instanceof Error ? e.message : 'Could not save this batch.'),
  });
  const set = (key: keyof BatchForm, value: string) => setForm((f) => ({ ...f, [key]: value }));
  return <Modal open onClose={onClose} title={batch ? `Edit ${batch.code}` : 'Start a cultivation batch'} size="lg"
    footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button variant="primary" loading={save.isPending} onClick={() => { if (!form.name.trim() || !form.species.trim()) { setError('Enter a batch name and species.'); return; } setError(''); save.mutate(); }}>{batch ? 'Save changes' : 'Create batch'}</Button></>}>
    <div className="grid gap-3 sm:grid-cols-2">
      <Field label="Batch name" required><Input value={form.name} maxLength={128} onChange={(e) => set('name', e.target.value)} placeholder="e.g. North shelf — October" /></Field>
      <Field label="Species" required><Input list="species-options" value={form.species} onChange={(e) => set('species', e.target.value)} placeholder="Oyster mushroom" /><datalist id="species-options"><option value="Oyster mushroom"/><option value="Lion's mane"/><option value="Shiitake"/></datalist></Field>
      <Field label="Strain" hint="Optional"><Input value={form.strain} onChange={(e) => set('strain', e.target.value)} placeholder="If known" /></Field>
      <Field label="Substrate" hint="Optional"><Input value={form.substrate_type} onChange={(e) => set('substrate_type', e.target.value)} placeholder="Pasteurized straw" /></Field>
      <Field label="Spawn details" hint="Optional; ratio or spawn lot"><Input value={form.spawn_details} onChange={(e) => set('spawn_details', e.target.value)} placeholder="e.g. 1:10 spawn-to-substrate" /></Field>
      <Field label="Cultivation profile" hint="Sets stage guidance and target ranges"><Select value={form.profile_id} onChange={(e) => set('profile_id', e.target.value)}><option value="">Use system defaults</option>{profiles.map((p) => <option key={p.id} value={p.id}>{p.name} · {p.species}</option>)}</Select></Field>
      <Field label="Batch status">
        <Select value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}>
          <option value="planned">Planned</option><option value="active">Active</option>
          {batch ? <><option value="harvested">Harvested</option><option value="failed">Failed</option><option value="archived">Archived</option></> : null}
        </Select>
      </Field>
      {!batch && <label className="flex items-center gap-2 self-end pb-2 text-xs text-ink-2"><input type="checkbox" checked={form.link_device} onChange={(e) => setForm((f) => ({ ...f, link_device: e.target.checked }))} disabled={!deviceId}/> Link to selected chamber{!deviceId && ' (no chamber available)'}</label>}
      <Field label="Inoculation date" hint="Optional; stage changes still need your confirmation"><Input type="date" value={form.inoculation_date} onChange={(e) => set('inoculation_date', e.target.value)} /></Field>
      <Field label="Notes" className="sm:col-span-2"><Textarea value={form.notes} maxLength={4000} onChange={(e) => set('notes', e.target.value)} placeholder="Spawn-to-substrate ratio, preparation details, or anything to remember" /></Field>
    </div>
    {error && <p role="alert" className="mt-3 text-xs text-danger">{error}</p>}
  </Modal>;
}

function BatchDetail({ batch, onEdit }: { batch: Batch; onEdit: () => void }) {
  const queryClient = useQueryClient();
  const toast = useToast();
  const [stageOpen, setStageOpen] = useState(false);
  const [observationOpen, setObservationOpen] = useState(false);
  const [stageKey, setStageKey] = useState(batch.current_stage_key ?? '');
  const [stageNote, setStageNote] = useState('');
  const [obs, setObs] = useState({ kind: 'note', note: '', yield_g: '', observed_at: localDateTimeValue() });
  const detail = useQuery({ queryKey: ['batches', batch.id], queryFn: () => endpoints.batch(batch.id) });
  const timeline = useQuery({ queryKey: ['batches', batch.id, 'timeline'], queryFn: () => endpoints.timeline(batch.id) });
  const observations = useQuery({ queryKey: ['batches', batch.id, 'observations'], queryFn: () => endpoints.observations(batch.id) });
  const update = useMutation({ mutationFn: () => endpoints.confirmStage(batch.id, { stage_key: stageKey, note: stageNote || undefined }), onSuccess: async () => { await Promise.all([queryClient.invalidateQueries({ queryKey: ['batches'] }), queryClient.invalidateQueries({ queryKey: ['batches', batch.id] })]); toast.success('Stage confirmation recorded'); setStageOpen(false); setStageNote(''); } });
  const addObservation = useMutation({ mutationFn: () => endpoints.createObservation(batch.id, { observed_at: new Date(obs.observed_at).toISOString(), kind: obs.kind, note: obs.note.trim(), data: obs.kind === 'harvest' && obs.yield_g ? { yield_g: Number(obs.yield_g) } : undefined, stage_key: batch.current_stage_key ?? undefined }), onSuccess: async () => { await Promise.all([queryClient.invalidateQueries({ queryKey: ['batches', batch.id] }), queryClient.invalidateQueries({ queryKey: ['batches'] })]); toast.success('Cultivation record added'); setObservationOpen(false); setObs({ kind: 'note', note: '', yield_g: '', observed_at: localDateTimeValue() }); } });
  const stages = timeline.data?.stages ?? batch.profile?.stages.map((s, i) => ({ ...s, index: i, state: s.key === batch.current_stage_key ? 'current' : 'upcoming', started_at: null, ended_at: null, actual_duration_days: null, events: [], observations: [] })) ?? [];
  const records = (detail.data?.observations ?? observations.data ?? []) as Observation[];
  return <div className="space-y-4">
    <Card title={<span className="flex items-center gap-2"><Sprout className="h-4 w-4 text-brand"/>{batch.name}</span>} subtitle={`${batch.code} · ${batch.species}${batch.strain ? ` · ${batch.strain}` : ''}`} actions={<><Badge tone={batch.status === 'active' ? 'brand' : 'neutral'}>{batch.status}</Badge><Button size="sm" onClick={onEdit}>Edit</Button></>}>
      <div className="grid gap-3 sm:grid-cols-3"><p className="text-xs text-ink-2"><span className="label block">Substrate</span>{batch.substrate_type ?? 'Not recorded'}</p><p className="text-xs text-ink-2"><span className="label block">Inoculated</span>{batch.inoculation_date ? fmtDateTime(batch.inoculation_date, 'dd MMM yyyy') : 'Not recorded'}</p><p className="text-xs text-ink-2"><span className="label block">Current stage</span>{batch.current_stage_name ?? 'Not set'}</p></div>
      {batch.notes && <p className="mt-3 border-t border-line pt-3 text-sm text-ink-2">{batch.notes}</p>}
      <div className="mt-4 flex flex-wrap gap-2"><Button variant="primary" icon={<Check className="h-4 w-4"/>} onClick={() => { setStageKey(batch.current_stage_key ?? stages[0]?.key ?? ''); setStageOpen(true); }}>Confirm stage</Button><Button icon={<Plus className="h-4 w-4"/>} onClick={() => setObservationOpen(true)}>Record observation</Button></div>
    </Card>
    <Card title="Cultivation lifecycle" subtitle="Progress is recorded from grower confirmation, never inferred from elapsed time." padded={false}>
      {timeline.isLoading ? <Loading label="Loading stage history…" className="px-4"/> : timeline.error ? <ErrorState error={timeline.error} onRetry={() => timeline.refetch()}/> : stages.length ? <ol className="divide-y divide-line">{stages.map((s) => <li key={s.key} className="flex gap-3 px-4 py-3"><div className={`mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${s.state === 'completed' ? 'bg-brand/15 text-brand' : s.state === 'current' ? 'bg-brand text-white' : 'bg-surface-3 text-ink-3'}`}>{s.state === 'completed' ? <Check className="h-3.5 w-3.5"/> : <span className="text-[10px]">{s.index + 1}</span>}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-ink">{s.name}</p>{s.state === 'current' && <Badge tone="brand">Current</Badge>}</div><p className="mt-1 text-xs text-ink-2">{s.description}</p>{s.started_at && <p className="mt-1 text-[11px] text-ink-3">Recorded {fmtDateTime(s.started_at, 'dd MMM yyyy')}</p>}<p className="mt-1 text-[11px] text-ink-3">Transition cue: {s.transition_criteria}</p></div></li>)}</ol> : <EmptyState title="No lifecycle profile assigned" description="Edit this batch and choose a species profile to see stage guidance."/>}
    </Card>
    <Card title="Observations & harvest records" subtitle="Notes and measurements captured for this batch." actions={<Button size="sm" icon={<Plus className="h-3.5 w-3.5"/>} onClick={() => setObservationOpen(true)}>Add record</Button>} padded={false}>
      {observations.isLoading ? <Loading className="px-4"/> : observations.error ? <ErrorState error={observations.error} onRetry={() => observations.refetch()}/> : records.length ? <ul className="divide-y divide-line">{records.map((o) => <li key={o.id} className="px-4 py-3"><div className="flex flex-wrap items-center gap-2"><Badge tone={o.kind === 'contamination' ? 'amber' : o.kind === 'harvest' ? 'brand' : 'neutral'}>{o.kind.replace('_', ' ')}</Badge><span className="text-[11px] text-ink-3">{fmtDateTime(o.observed_at, 'dd MMM yyyy · HH:mm')}</span></div><p className="mt-1 text-sm text-ink-2">{o.note}</p>{o.data?.yield_g != null && <p className="mt-1 text-xs font-medium text-ink">Yield recorded: {String(o.data.yield_g)} g</p>}</li>)}</ul> : <EmptyState title="No observations yet" description="Record visual changes, contamination concerns, pinning, or harvest yield." />}
    </Card>
    <Modal open={stageOpen} onClose={() => setStageOpen(false)} title="Confirm a cultivation stage" footer={<><Button variant="ghost" onClick={() => setStageOpen(false)}>Cancel</Button><Button variant="primary" loading={update.isPending} onClick={() => update.mutate()}>Save stage</Button></>}><div className="space-y-3"><p className="text-xs text-ink-2">Only confirm after observing the batch. This creates a dated lifecycle record.</p><Field label="Observed stage"><Select value={stageKey} onChange={(e) => setStageKey(e.target.value)}>{stages.map((s) => <option key={s.key} value={s.key}>{s.name}</option>)}</Select></Field><Field label="Observation (optional)"><Textarea value={stageNote} onChange={(e) => setStageNote(e.target.value)} placeholder="What did you see that supports this transition?"/></Field>{update.error && <p role="alert" className="text-xs text-danger">{update.error instanceof Error ? update.error.message : 'Stage could not be updated.'}</p>}</div></Modal>
    <Modal open={observationOpen} onClose={() => setObservationOpen(false)} title="Record batch observation" footer={<><Button variant="ghost" onClick={() => setObservationOpen(false)}>Cancel</Button><Button variant="primary" loading={addObservation.isPending} disabled={!obs.note.trim() || !obs.observed_at} onClick={() => addObservation.mutate()}>Save record</Button></>}><div className="space-y-3"><Field label="Record type"><Select value={obs.kind} onChange={(e) => { const value = e.currentTarget.value; setObs((v) => ({ ...v, kind: value })); }}><option value="note">Observation</option><option value="contamination">Contamination concern</option><option value="harvest">Harvest</option><option value="measurement">Measurement</option></Select></Field><Field label="Observed at"><Input type="datetime-local" value={obs.observed_at} onChange={(e) => { const value = e.currentTarget.value; setObs((v) => ({ ...v, observed_at: value })); }}/></Field>{obs.kind === 'harvest' && <Field label="Yield (g)" hint="Optional"><Input type="number" min="0" step="1" value={obs.yield_g} onChange={(e) => { const value = e.currentTarget.value; setObs((v) => ({ ...v, yield_g: value })); }}/></Field>}<Field label="Notes" required><Textarea maxLength={4000} value={obs.note} onChange={(e) => { const value = e.currentTarget.value; setObs((v) => ({ ...v, note: value })); }} placeholder="Describe the visible observation or record"/></Field>{addObservation.error && <p role="alert" className="text-xs text-danger">{addObservation.error instanceof Error ? addObservation.error.message : 'Record could not be saved.'}</p>}</div></Modal>
  </div>;
}

export default function Batches() {
  const { data: batches, isLoading, error, refetch } = useBatches();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [editor, setEditor] = useState<'create' | Batch | null>(null);
  const active = useMemo(() => batches?.filter((b) => b.status === 'active').length ?? 0, [batches]);
  const selected = batches?.find((b) => b.id === selectedId) ?? null;
  return <div className="space-y-4">
    <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="label">Cultivation records</p><h1 className="mt-1 font-display text-2xl text-ink">Batches</h1><p className="mt-1 text-sm text-ink-2">Follow each crop from inoculation through harvest, with dated observations.</p></div><Button variant="primary" icon={<Plus className="h-4 w-4"/>} onClick={() => setEditor('create')}>New batch</Button></div>
    <div className="grid gap-4 lg:grid-cols-[minmax(240px,0.75fr)_minmax(0,1.6fr)]">
      <Card title="Your batches" subtitle={`${active} active`} padded={false}>{isLoading ? <Loading label="Loading batches…" className="px-4"/> : error ? <ErrorState error={error} onRetry={() => refetch()}/> : batches?.length ? <ul className="divide-y divide-line">{batches.map((b) => <li key={b.id}><button type="button" onClick={() => setSelectedId(b.id)} aria-current={selectedId === b.id ? 'true' : undefined} className={`w-full px-4 py-3 text-left transition-colors hover:bg-surface-2 ${selectedId === b.id ? 'bg-surface-2' : ''}`}><div className="flex items-center justify-between gap-2"><span className="truncate text-sm font-semibold text-ink">{b.name}</span><ChevronRight className="h-4 w-4 shrink-0 text-ink-3"/></div><div className="mt-1 flex flex-wrap items-center gap-2"><span className="font-mono text-[10px] text-ink-3">{b.code}</span><Badge tone={b.status === 'active' ? 'brand' : 'neutral'}>{b.status}</Badge></div><p className="mt-1 text-xs text-ink-2">{b.species} · {b.current_stage_name ?? 'Stage not set'}</p></button></li>)}</ul> : <EmptyState title="No batches recorded" description="Create a batch to start tracking its lifecycle." action={<Button size="sm" variant="primary" onClick={() => setEditor('create')}>Create batch</Button>}/>}</Card>
      {selected ? <BatchDetail key={selected.id} batch={selected} onEdit={() => setEditor(selected)}/> : <Card className="min-h-64"><EmptyState title="Choose a batch to view its progress" description="Lifecycle stages, records, and environmental history stay attached to the selected batch." icon={<Leaf className="h-6 w-6"/>}/></Card>}
    </div>
    {editor && <BatchEditor batch={editor === 'create' ? undefined : editor} onClose={() => setEditor(null)}/>}
  </div>;
}

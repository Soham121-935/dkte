import { Suspense, lazy } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { AppShell } from './components/layout/AppShell';
import { Loading } from './components/ui';

const Home = lazy(() => import('./pages/Home'));
const Stats = lazy(() => import('./pages/Stats'));
const Predictions = lazy(() => import('./pages/Predictions'));
const Batches = lazy(() => import('./pages/Batches'));
const Monitoring = lazy(() => import('./pages/Monitoring'));
const Knowledge = lazy(() => import('./pages/Knowledge'));
const Activity = lazy(() => import('./pages/Activity'));

/**
 * Cultivation workspaces share one app shell and one backend data source.
 * The routes keep monitoring, batches, history, insight, and references in
 * separate focused screens while the assistant is available throughout.
 */
export default function App() {
  return (
    <AppShell>
      <Suspense fallback={<Loading label="Loading page…" />}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/batches" element={<Batches />} />
          <Route path="/monitoring" element={<Monitoring />} />
          <Route path="/activity" element={<Activity />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/predictions" element={<Predictions />} />
          <Route path="/knowledge" element={<Knowledge />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </AppShell>
  );
}
